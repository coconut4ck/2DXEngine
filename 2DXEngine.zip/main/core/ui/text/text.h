#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <string>
#include <unordered_map>
#include <vector>

#include <ft2build.h>
#include FT_FREETYPE_H

class Shader;

struct Character {
    unsigned int textureID = 0;
    glm::ivec2   size{0, 0};
    glm::ivec2   bearing{0, 0};
    unsigned int advance = 0;
};

class Text {
public:
    glm::vec2 position{0.0f, 0.0f};
    float rotation = 0.0f;
    float scale    = 1.0f;
    float alpha    = 1.0f;
    glm::vec3 tint{1.0f, 1.0f, 1.0f};

    std::string text;

    unsigned int pixelSize = 48;
    float lineSpacing = 0.0f;

    unsigned int VAO = 0, VBO = 0;

    std::unordered_map<uint32_t, Character> characters;
    bool initialized = false;

    Text() = default;
    ~Text();

    void create(const char* text, const char* fontPath = "core/res/fonts/font1.ttf");
    void setText(const std::string& newText);
    void draw();
    void destroy();

    bool visible = true;
    void show();
    void hide();

    glm::mat4 modelMatrix() const;
    glm::vec2 measure() const;

private:
    void loadFont(const char* fontPath);
    Character& getGlyph(uint32_t codepoint);

    Shader* shader = nullptr;

    FT_Face    face     = nullptr;
    FT_Library ft       = nullptr;
    bool       ftInited = false;
};