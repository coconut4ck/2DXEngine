#include "text.h"
#include <core/other/shader.h>
#include <glm/gtc/matrix_transform.hpp>
#include <ft2build.h>
#include FT_FREETYPE_H
#include <iostream>

Text::~Text() {
    destroy();
    if (face)     { FT_Done_Face(face);     face = nullptr; }
    if (ftInited) { FT_Done_FreeType(ft);   ftInited = false; }
}

static uint32_t decodeUTF8(const std::string& s, size_t& i) {
    unsigned char c = static_cast<unsigned char>(s[i]);

    if (c < 0x80) { i += 1; return c; }

    if ((c >> 5) == 0x6 && i + 1 < s.size()) {
        uint32_t cp = ((c & 0x1F) << 6) |
                      (static_cast<unsigned char>(s[i+1]) & 0x3F);
        i += 2; return cp;
    }
    if ((c >> 4) == 0xE && i + 2 < s.size()) {
        uint32_t cp = ((c & 0x0F) << 12) |
                      ((static_cast<unsigned char>(s[i+1]) & 0x3F) << 6) |
                       (static_cast<unsigned char>(s[i+2]) & 0x3F);
        i += 3; return cp;
    }
    if ((c >> 3) == 0x1E && i + 3 < s.size()) {
        uint32_t cp = ((c & 0x07) << 18) |
                      ((static_cast<unsigned char>(s[i+1]) & 0x3F) << 12) |
                      ((static_cast<unsigned char>(s[i+2]) & 0x3F) << 6)  |
                       (static_cast<unsigned char>(s[i+3]) & 0x3F);
        i += 4; return cp;
    }

    i += 1;
    return '?';
}

void Text::loadFont(const char* fontPath) {
    if (initialized) return;

    if (FT_Init_FreeType(&ft)) {
        std::cerr << "FreeType: init failed\n";
        return;
    }
    ftInited = true;

    if (FT_New_Face(ft, fontPath, 0, &face)) {
        std::cerr << "FreeType: font not found: " << fontPath << "\n";
        FT_Done_FreeType(ft);
        ftInited = false;
        return;
    }

    FT_Set_Pixel_Sizes(face, 0, pixelSize);

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * 4 * 512,
                 nullptr, GL_DYNAMIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    if (lineSpacing == 0.0f)
        lineSpacing = static_cast<float>(pixelSize);

    shader = ShaderCache::get(
        "core/shaders/text/vertex.glsl",
        "core/shaders/text/fragment.glsl"
    );

    for (uint32_t c = 32; c < 128; ++c)
        getGlyph(c);

    initialized = true;
}

Character& Text::getGlyph(uint32_t codepoint) {
    auto it = characters.find(codepoint);
    if (it != characters.end()) return it->second;

    Character ch{};

    if (!face || FT_Load_Char(face, codepoint, FT_LOAD_RENDER)) {
        characters[codepoint] = ch;
        return characters[codepoint];
    }

    unsigned int texID;
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glGenTextures(1, &texID);
    glBindTexture(GL_TEXTURE_2D, texID);
    glTexImage2D(
        GL_TEXTURE_2D, 0, GL_RED,
        face->glyph->bitmap.width,
        face->glyph->bitmap.rows,
        0, GL_RED, GL_UNSIGNED_BYTE,
        face->glyph->bitmap.buffer
    );
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    ch.textureID = texID;
    ch.size      = glm::ivec2(face->glyph->bitmap.width, face->glyph->bitmap.rows);
    ch.bearing   = glm::ivec2(face->glyph->bitmap_left, face->glyph->bitmap_top);
    ch.advance   = static_cast<unsigned int>(face->glyph->advance.x);

    characters[codepoint] = ch;
    return characters[codepoint];
}

void Text::create(const char* txt, const char* fontPath) {
    loadFont(fontPath);
    setText(txt ? txt : "");
}

void Text::setText(const std::string& newText) {
    text = newText;
}

glm::mat4 Text::modelMatrix() const {
    glm::mat4 m = glm::mat4(1.0f);
    m = glm::translate(m, glm::vec3(position, 0.0f));
    m = glm::rotate(m, glm::radians(rotation), glm::vec3(0.0f, 0.0f, 1.0f));
    m = glm::scale(m, glm::vec3(scale, scale, 1.0f));
    return m;
}

glm::vec2 Text::measure() const {
    float maxX = 0.0f, curX = 0.0f, curY = 0.0f, minY = 0.0f;

    for (size_t i = 0; i < text.size(); ) {
        uint32_t cp = decodeUTF8(text, i);
        if (cp == '\n') {
            maxX = glm::max(maxX, curX);
            curX = 0.0f;
            curY -= lineSpacing;
            minY = glm::min(minY, curY);
            continue;
        }
        auto it = characters.find(cp);
        if (it == characters.end()) continue;
        curX += (it->second.advance >> 6);
    }
    maxX = glm::max(maxX, curX);
    return glm::vec2(maxX, -minY + pixelSize);
}

void Text::draw() {
    if (!visible || !initialized || !shader) return;

    shader->use();
    shader->setMat4("uModel", modelMatrix());
    shader->setVec3 ("uTint",  tint);
    shader->setInt  ("uTexture", 0);
    shader->setFloat("alpha", alpha);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glActiveTexture(GL_TEXTURE0);
    glBindVertexArray(VAO);

    std::vector<std::vector<uint32_t>> lines;
    lines.emplace_back();

    for (size_t i = 0; i < text.size(); ) {
        uint32_t cp = decodeUTF8(text, i);
        if (cp == '\n') lines.emplace_back();
        else            lines.back().push_back(cp);
    }

    float totalHeight = (lines.size() - 1) * lineSpacing;
    float y = totalHeight * 0.5f + pixelSize * 0.3f;

    for (auto& line : lines) {
        float lineWidth = 0.0f;
        for (uint32_t cp : line) {
            Character& ch = getGlyph(cp);
            lineWidth += (ch.advance >> 6);
        }

        float x = -lineWidth * 0.5f;

        for (uint32_t cp : line) {
            Character& ch = getGlyph(cp);
            if (ch.textureID == 0) continue;

            float xpos = x + ch.bearing.x;
            float ypos = y + (ch.size.y - ch.bearing.y);
            float w = static_cast<float>(ch.size.x);
            float h = static_cast<float>(ch.size.y);

            float vertices[6][4] = {
                { xpos,     ypos - h, 0.0f, 0.0f },
                { xpos,     ypos,     0.0f, 1.0f },
                { xpos + w, ypos,     1.0f, 1.0f },

                { xpos,     ypos - h, 0.0f, 0.0f },
                { xpos + w, ypos,     1.0f, 1.0f },
                { xpos + w, ypos - h, 1.0f, 0.0f }
            };

            glBindTexture(GL_TEXTURE_2D, ch.textureID);
            glBindBuffer(GL_ARRAY_BUFFER, VBO);
            glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices);
            glDrawArrays(GL_TRIANGLES, 0, 6);

            x += (ch.advance >> 6);
        }
        y += lineSpacing;
    }

    glBindVertexArray(0);
    glBindTexture(GL_TEXTURE_2D, 0);
}

void Text::destroy() {
    for (auto& [cp, ch] : characters) {
        if (ch.textureID) glDeleteTextures(1, &ch.textureID);
    }
    characters.clear();

    if (VBO) { glDeleteBuffers(1, &VBO); VBO = 0; }
    if (VAO) { glDeleteVertexArrays(1, &VAO); VAO = 0; }

    shader = nullptr;
    initialized = false;
}

void Text::show() {
    if (visible != true) visible = true;
}

void Text::hide() {
    if (visible != false) visible = false;
}