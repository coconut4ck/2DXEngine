#include "texture_panel.h"
#include <core/other/shader.h>
#include <glm/gtc/matrix_transform.hpp>
#include <core/libs/stb/stb_image.h>
#include <iostream>

TexturePanel::~TexturePanel() { destroy(); }

unsigned int TexturePanel::loadTexture(const char* path, int& w, int& h) {
    if (!path || path[0] == '\0') {
        unsigned int id;
        glGenTextures(1, &id);
        glBindTexture(GL_TEXTURE_2D, id);

        unsigned char white[4] = {255, 255, 255, 255};
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 1, 1, 0,
                     GL_RGBA, GL_UNSIGNED_BYTE, white);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        w = h = 1;
        return id;
    }

    stbi_set_flip_vertically_on_load(true);

    int channels;
    unsigned char* data = stbi_load(path, &w, &h, &channels, 4);
    if (!data) {
        std::cerr << "Failed to load texture: " << path
                  << " (" << stbi_failure_reason() << ")\n";
        return 0;
    }

    unsigned int id;
    glGenTextures(1, &id);
    glBindTexture(GL_TEXTURE_2D, id);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0,
                 GL_RGBA, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

    stbi_image_free(data);
    return id;
}

void TexturePanel::setTexture(const std::string& path) {
    if (texturePath != path) {
        if (textureID) {
            glDeleteTextures(1, &textureID);
            textureID = 0;
        }

        texturePath = path;

        int w = 0, h = 0;
        textureID = loadTexture(path.empty() ? nullptr : path.c_str(), w, h);
        texWidth  = w;
        texHeight = h;
    }
}

void TexturePanel::create(const char* path) {
    float vertices[] = {
        -0.5f, -0.5f,  0.0f, 1.0f,
         0.5f, -0.5f,  1.0f, 1.0f,
         0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.0f, 0.0f
    };

    unsigned int indices[] = { 0, 1, 2, 2, 3, 0 };
    indexCount = 6;

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float),
                          (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);

    textureID = loadTexture(path, texWidth, texHeight);

    shader = ShaderCache::get(
        "core/shaders/panel/texture/vertex.glsl",
        "core/shaders/panel/texture/fragment.glsl"
    );
}

glm::mat4 TexturePanel::modelMatrix() const {
    glm::mat4 m = glm::mat4(1.0f);
    m = glm::translate(m, glm::vec3(position, 0.0f));
    m = glm::rotate(m, glm::radians(rotation), glm::vec3(0.0f, 0.0f, 1.0f));
    m = glm::scale(m, glm::vec3(scale, 1.0f));
    return m;
}

void TexturePanel::draw() {
    if (visible == true) {
        if (!shader) return;

        shader->use();
        shader->setMat4("uModel", modelMatrix());
        shader->setVec3 ("uTint",  tint);
        shader->setFloat("alpha",  alpha);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureID);
        shader->setInt("uTexture", 0);

        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, 0);
    }
}

void TexturePanel::destroy() {
    if (textureID) { glDeleteTextures(1, &textureID); textureID = 0; }
    if (EBO) glDeleteBuffers(1, &EBO);
    if (VBO) glDeleteBuffers(1, &VBO);
    if (VAO) glDeleteVertexArrays(1, &VAO);
    EBO = VBO = VAO = 0;
    shader = nullptr;
}

void TexturePanel::show() {
    if (visible != true) {
     visible = true;
    }
}

void TexturePanel::hide() {
    if (visible != false) {
     visible = false;
    }
}