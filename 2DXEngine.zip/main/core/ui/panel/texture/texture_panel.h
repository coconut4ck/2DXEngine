#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <string>

class Shader;

class TexturePanel {
public:
    glm::vec2 position{0.0f, 0.0f};
    float rotation = 0.0f;
    glm::vec2 scale{100.0f, 100.0f};

    glm::vec3 tint{1.0f, 1.0f, 1.0f};

    float alpha = 1.0f;

    int texWidth = 0, texHeight = 0;

    unsigned int VAO = 0, VBO = 0, EBO = 0;
    int indexCount = 0;

    void setTexture(const std::string& path);
    const std::string& getTexture() const { return texturePath; }

    struct TextureProperty {
        TexturePanel* panel;
        TextureProperty& operator=(const std::string& path) {
            panel->setTexture(path);
            return *this;
        }
        operator std::string() const { return panel->texturePath; }
        const char* c_str() const { return panel->texturePath.c_str(); }
    };
    TextureProperty texture{this};

    TexturePanel() = default;
    ~TexturePanel();

    void create(const char* path = nullptr);

    void draw();
    void destroy();

    bool visible = true;
    void show();
    void hide();

    glm::mat4 modelMatrix() const;

private:
    unsigned int textureID = 0;
    std::string texturePath;

    static unsigned int loadTexture(const char* path, int& w, int& h);
    Shader* shader = nullptr;
};