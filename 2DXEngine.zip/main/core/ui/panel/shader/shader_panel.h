#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <string>
#include <map>

class Shader;

class ShaderPanel {
public:
    glm::vec2 position{0.0f, 0.0f};
    float rotation = 0.0f;
    glm::vec2 scale{100.0f, 100.0f};

    float alpha = 1.0f;
    glm::vec3 tint{1.0f, 1.0f, 1.0f};

    float time = 0.0f;

    unsigned int VAO = 0, VBO = 0, EBO = 0;
    int indexCount = 0;

    ShaderPanel() = default;
    ~ShaderPanel();

    void create(const char* vertexPath, const char* fragmentPath);

    void draw();
    void destroy();

    void setFloat(const char* name, float v);
    void setVec2 (const char* name, const glm::vec2& v);
    void setVec3 (const char* name, const glm::vec3& v);
    void setVec4 (const char* name, const glm::vec4& v);
    void setInt  (const char* name, int v);

    bool visible = true;
    void show();
    void hide();

    void update(float dt) { time += dt; }

    glm::mat4 modelMatrix() const;

    Shader* getShader() const { return shader; }

private:
    Shader* shader = nullptr;

    std::map<std::string, float>       floats;
    std::map<std::string, glm::vec2>   vec2s;
    std::map<std::string, glm::vec3>   vec3s;
    std::map<std::string, glm::vec4>   vec4s;
    std::map<std::string, int>         ints;
};