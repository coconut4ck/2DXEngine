#include "shader_panel.h"
#include <core/other/shader.h>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>

ShaderPanel::~ShaderPanel() { destroy(); }

void ShaderPanel::create(const char* vertexPath, const char* fragmentPath) {
    float vertices[] = {
        -0.5f, -0.5f,  0.0f, 1.0f,
         0.5f, -0.5f,  1.0f, 1.0f,
         0.5f,  0.5f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.0f, 0.0f
    };

    unsigned int indices[] = { 0, 1, 2, 2, 3, 0 };
    indexCount = 6;

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 4 * sizeof(float),
                          (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindVertexArray(0);

    shader = ShaderCache::get(vertexPath, fragmentPath);
}

glm::mat4 ShaderPanel::modelMatrix() const {
    glm::mat4 m = glm::mat4(1.0f);
    m = glm::translate(m, glm::vec3(position, 0.0f));
    m = glm::rotate(m, glm::radians(rotation), glm::vec3(0.0f, 0.0f, 1.0f));
    m = glm::scale(m, glm::vec3(scale, 1.0f));
    return m;
}

void ShaderPanel::draw() {
    if (visible == true) {
        if (!shader || !shader->ID) return;

        shader->use();

        shader->setMat4 ("uModel", modelMatrix());
        shader->setFloat("alpha",  alpha);
        shader->setVec3 ("uTint",  tint);
        shader->setFloat("uTime",  time);

        for (auto& [k, v] : floats) shader->setFloat(k.c_str(), v);
        for (auto& [k, v] : vec2s)  shader->setVec3 (k.c_str(), glm::vec3(v, 0.0f));
        for (auto& [k, v] : vec3s)  shader->setVec3 (k.c_str(), v);
        for (auto& [k, v] : vec4s)  shader->setVec4 (k.c_str(), v);
        for (auto& [k, v] : ints)   shader->setInt  (k.c_str(), v);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }
}

void ShaderPanel::destroy() {
    shader = nullptr;

    if (EBO) glDeleteBuffers(1, &EBO);
    if (VBO) glDeleteBuffers(1, &VBO);
    if (VAO) glDeleteVertexArrays(1, &VAO);
    EBO = VBO = VAO = 0;

    floats.clear(); vec2s.clear(); vec3s.clear(); vec4s.clear(); ints.clear();
}

void ShaderPanel::setFloat(const char* name, float v)            { floats[name] = v; }
void ShaderPanel::setVec2 (const char* name, const glm::vec2& v) { vec2s[name]  = v; }
void ShaderPanel::setVec3 (const char* name, const glm::vec3& v) { vec3s[name]  = v; }
void ShaderPanel::setVec4 (const char* name, const glm::vec4& v) { vec4s[name]  = v; }
void ShaderPanel::setInt  (const char* name, int v)              { ints[name]   = v; }


void ShaderPanel::show() {
    if (visible != true) {
     visible = true;
    }
}

void ShaderPanel::hide() {
    if (visible != false) {
     visible = false;
    }
}