#include "color_panel.h"
#include <core/other/shader.h>
#include <glm/gtc/matrix_transform.hpp>

ColorPanel::~ColorPanel() { destroy(); }

void ColorPanel::create(const glm::vec3& c) {
    color = c;

    float vertices[] = {
        -0.5f, -0.5f, 1.0f, 1.0f, 1.0f,
         0.5f, -0.5f, 1.0f, 1.0f, 1.0f,
         0.5f,  0.5f, 1.0f, 1.0f, 1.0f,
        -0.5f,  0.5f, 1.0f, 1.0f, 1.0f
    };

    unsigned int indices[] = { 0, 1, 2, 2, 3, 0 };
    indexCount = 6;

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glBindVertexArray(0);

    shader = ShaderCache::get(
        "core/shaders/panel/color/vertex.glsl",
        "core/shaders/panel/color/fragment.glsl"
    );
}

glm::mat4 ColorPanel::modelMatrix() const {
    glm::mat4 m = glm::mat4(1.0f);
    m = glm::translate(m, glm::vec3(position, 0.0f));
    m = glm::rotate(m, glm::radians(rotation), glm::vec3(0.0f, 0.0f, 1.0f));
    m = glm::scale(m, glm::vec3(scale, 1.0f));
    return m;
}

void ColorPanel::draw() {
    if (visible == true) {
        if (!shader) return;
        shader->use();
        shader->setMat4("uModel", modelMatrix());
        shader->setVec3 ("uColor", color);
        shader->setFloat("alpha",  alpha);

        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, 0);
    }
}

void ColorPanel::destroy() {
    if (EBO) glDeleteBuffers(1, &EBO);
    if (VBO) glDeleteBuffers(1, &VBO);
    if (VAO) glDeleteVertexArrays(1, &VAO);
    EBO = VBO = VAO = 0;
    shader = nullptr;
}

void ColorPanel::show() {
    if (visible != true) {
     visible = true;
    }
}

void ColorPanel::hide() {
    if (visible != false) {
     visible = false;
    }
}