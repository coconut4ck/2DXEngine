#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>

class Shader;

class ColorPanel {
public:
    glm::vec2 position{0.0f, 0.0f};
    float rotation = 0.0f;
    glm::vec2 scale{100.0f, 100.0f};

    glm::vec3 color{1.0f, 1.0f, 1.0f};
    float alpha = 1.0f;

    unsigned int VAO = 0, VBO = 0, EBO = 0;
    int indexCount = 0;

    ColorPanel() = default;
    ~ColorPanel();

    void create(const glm::vec3& color = {1.0f, 1.0f, 1.0f});
    void draw();
    void destroy();

    bool visible = true;
    void show();
    void hide();

    glm::mat4 modelMatrix() const;

private:
    Shader* shader = nullptr;
};