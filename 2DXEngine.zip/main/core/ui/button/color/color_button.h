#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>

#include <core/ui/panel/color/color_panel.h>
#include "core/ui/text/text.h"

class Shader;

class ColorButton {
public:
    glm::vec2 position{0.0f, 0.0f};
    float rotation = 0.0f;
    glm::vec2 scale{100.0f, 100.0f};
    glm::vec3 color{1.0f, 1.0f, 1.0f};
    float alpha = 1.0f;

    const char* text = "";
    float text_scale = 1.0f;
    unsigned int pixelSize = 48;
    float lineSpacing = 0.0f;
    glm::vec3 tint{1.0f, 1.0f, 1.0f};


    ColorButton() = default;
    ~ColorButton();

    void create(const glm::vec3& color = {1.0f, 1.0f, 1.0f},
                const char* text = "",
                const char* fontPath = "core/res/fonts/font1.ttf");

    void draw();
    void destroy();

    bool visible = true;
    void show();
    void hide();

    bool is_pressed();
    bool is_click();
    bool is_hovered();

private:
    bool clickConsumed = false;

    bool prevPressed = false;
    Text T_color_button;
    ColorPanel CP_color_button;
};