#include "color_button.h"
#include <core/other/shader.h>
#include <glm/gtc/matrix_transform.hpp>
#include <GLFW/glfw3.h>
#include <cmath>

#include <core/ui/panel/color/color_panel.h>
#include "core/ui/text/text.h"
#include <core/main/settings.h>


static bool getVirtualMouse(glm::vec2& out) {
    GLFWwindow* window = glfwGetCurrentContext();
    if (!window) return false;

    double mx, my;
    glfwGetCursorPos(window, &mx, &my);

    int winW, winH, fbW, fbH;
    glfwGetWindowSize(window, &winW, &winH);
    glfwGetFramebufferSize(window, &fbW, &fbH);

    float sx = (winW > 0) ? (float)fbW / (float)winW : 1.0f;
    float sy = (winH > 0) ? (float)fbH / (float)winH : 1.0f;

    float fx = (float)mx * sx;
    float fy = (float)my * sy;

    Settings s;
    float vW = (float)s.v_width;
    float vH = (float)s.v_height;

    float windowAspect  = (fbH > 0) ? (float)fbW / (float)fbH : 1.0f;
    float virtualAspect = vW / vH;

    int vpX, vpY, vpW, vpH;
    if (windowAspect > virtualAspect) {
        vpH = fbH;
        vpW = (int)(fbH * virtualAspect);
        vpX = (fbW - vpW) / 2;
        vpY = 0;
    } else {
        vpW = fbW;
        vpH = (int)(fbW / virtualAspect);
        vpX = 0;
        vpY = (fbH - vpH) / 2;
    }

    if (fx < vpX || fx >= vpX + vpW || fy < vpY || fy >= vpY + vpH)
        return false;

    float u = (fx - vpX) / (float)vpW;
    float v = (fy - vpY) / (float)vpH;

    out.x = u * vW;
    out.y = v * vH;
    return true;
}


ColorButton::~ColorButton() { destroy(); }

void ColorButton::create(const glm::vec3& c, const char* txt, const char* fontPath) {
    color = c;
    text = txt ? txt : "";

    T_color_button.pixelSize = pixelSize;
    T_color_button.lineSpacing = lineSpacing;
    T_color_button.create(txt, fontPath);

    CP_color_button.create(c);
};

void ColorButton::draw() {
    if (visible == true) {
        if (text != T_color_button.text)
            T_color_button.setText(text);

        T_color_button.position = position;
        T_color_button.rotation = rotation;
        T_color_button.scale = text_scale;
        T_color_button.tint = tint;
        T_color_button.alpha = alpha;


        CP_color_button.position = position;
        CP_color_button.rotation = rotation;
        CP_color_button.scale = scale;
        CP_color_button.alpha = alpha;

        if (is_pressed()) {
            CP_color_button.color = color / 1.3f;
        } else if (is_hovered()) {
            CP_color_button.color = color / 1.1f;
        } else {
            CP_color_button.color = color;
        };

        CP_color_button.draw();
        T_color_button.draw();
    }
}

void ColorButton::destroy() {
    CP_color_button.destroy();
    T_color_button.destroy();
}

bool ColorButton::is_hovered() {
    glm::vec2 mouse;
    if (!getVirtualMouse(mouse)) return false;

    glm::vec2 diff = mouse - position;

    float c = std::cos(-rotation);
    float s = std::sin(-rotation);
    glm::vec2 local;
    local.x = diff.x * c - diff.y * s;
    local.y = diff.x * s + diff.y * c;

    float halfW = scale.x * 0.5f;
    float halfH = scale.y * 0.5f;

    return std::abs(local.x) <= halfW && std::abs(local.y) <= halfH;
}

bool ColorButton::is_pressed() {
    GLFWwindow* window = glfwGetCurrentContext();
    if (!window) return false;

    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) != GLFW_PRESS)
        return false;

    glm::vec2 mouse;
    if (!getVirtualMouse(mouse)) return false;

    glm::vec2 diff = mouse - position;

    float c = std::cos(-rotation);
    float s = std::sin(-rotation);
    glm::vec2 local;
    local.x = diff.x * c - diff.y * s;
    local.y = diff.x * s + diff.y * c;

    float halfW = scale.x * 0.5f;
    float halfH = scale.y * 0.5f;

    return std::abs(local.x) <= halfW && std::abs(local.y) <= halfH;
}

bool ColorButton::is_click() {
    GLFWwindow* window = glfwGetCurrentContext();
    if (!window) return false;

    glm::vec2 mouse;
    bool inside = getVirtualMouse(mouse);

    bool hovered = false;
    if (inside) {
        glm::vec2 diff = mouse - position;

        float c = std::cos(-rotation);
        float s = std::sin(-rotation);
        glm::vec2 local;
        local.x = diff.x * c - diff.y * s;
        local.y = diff.x * s + diff.y * c;

        float halfW = scale.x * 0.5f;
        float halfH = scale.y * 0.5f;

        hovered = std::abs(local.x) <= halfW && std::abs(local.y) <= halfH;
    }

    bool pressed = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;
    bool clicked = pressed && !prevPressed && hovered;
    prevPressed = pressed;

    return clicked;
}


void ColorButton::show() {
    if (visible != true) {
     visible = true;
    }
}

void ColorButton::hide() {
    if (visible != false) {
     visible = false;
    }
}