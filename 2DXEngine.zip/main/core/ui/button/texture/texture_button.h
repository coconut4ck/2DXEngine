#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>

#include <core/ui/panel/texture/texture_panel.h>

class Shader;

class TextureButton {
public:
    glm::vec2 position{0.0f, 0.0f};
    float rotation = 0.0f;
    glm::vec2 scale{100.0f, 100.0f};

    glm::vec3 tint{1.0f, 1.0f, 1.0f};

    float alpha = 1.0f;

    TextureButton() = default;
    ~TextureButton();

    void create(const char* path);

    void draw();

    void destroy();

    bool is_pressed();
    bool is_click();
    bool is_hovered();

    bool visible = true;
    void show();
    void hide();
private:
    bool prevPressed = false;
    TexturePanel TP_texture_button;
};