#include "texture_button.h"
#include <glm/gtc/matrix_transform.hpp>
#include <GLFW/glfw3.h>
#include <cmath>

#include <core/ui/panel/texture/texture_panel.h>
#include <core/main/settings.h>


static bool getVirtualMouse(glm::vec2& out) {
    GLFWwindow* window = glfwGetCurrentContext();
    if (!window) return false;

    double mx, my;
    glfwGetCursorPos(window, &mx, &my);

    int winW, winH, fbW, fbH;
    glfwGetWindowSize(window, &winW, &winH);
    glfwGetFramebufferSize(window, &fbW, &fbH);

    float sx = (winW > 0) ? (float)fbW / (float)winW : 1.0f;
    float sy = (winH > 0) ? (float)fbH / (float)winH : 1.0f;

    float fx = (float)mx * sx;
    float fy = (float)my * sy;

    Settings s;
    float vW = (float)s.v_width;
    float vH = (float)s.v_height;

    float windowAspect  = (fbH > 0) ? (float)fbW / (float)fbH : 1.0f;
    float virtualAspect = vW / vH;

    int vpX, vpY, vpW, vpH;
    if (windowAspect > virtualAspect) {
        vpH = fbH;
        vpW = (int)(fbH * virtualAspect);
        vpX = (fbW - vpW) / 2;
        vpY = 0;
    } else {
        vpW = fbW;
        vpH = (int)(fbW / virtualAspect);
        vpX = 0;
        vpY = (fbH - vpH) / 2;
    }

    if (fx < vpX || fx >= vpX + vpW || fy < vpY || fy >= vpY + vpH)
        return false;

    float u = (fx - vpX) / (float)vpW;
    float v = (fy - vpY) / (float)vpH;

    out.x = u * vW;
    out.y = v * vH;
    return true;
}


TextureButton::~TextureButton() { destroy(); }

void TextureButton::create(const char* path) {
    TP_texture_button.create(path);
};

void TextureButton::draw() {
    if (visible == true) {
        TP_texture_button.position = position;
        TP_texture_button.rotation = rotation;
        TP_texture_button.scale = scale;
        TP_texture_button.alpha = alpha;

        if (is_pressed()) {
            TP_texture_button.tint = tint / 1.3f;
        } else if (is_hovered()) {
            TP_texture_button.tint = tint / 1.1f;
        } else {
            TP_texture_button.tint = tint;
        };

        TP_texture_button.draw();
    }
}

void TextureButton::destroy() {
    TP_texture_button.destroy();
}

bool TextureButton::is_hovered() {
    glm::vec2 mouse;
    if (!getVirtualMouse(mouse)) return false;

    glm::vec2 diff = mouse - position;

    float c = std::cos(-rotation);
    float s = std::sin(-rotation);
    glm::vec2 local;
    local.x = diff.x * c - diff.y * s;
    local.y = diff.x * s + diff.y * c;

    float halfW = scale.x * 0.5f;
    float halfH = scale.y * 0.5f;

    return std::abs(local.x) <= halfW && std::abs(local.y) <= halfH;
}

bool TextureButton::is_pressed() {
    GLFWwindow* window = glfwGetCurrentContext();
    if (!window) return false;

    if (glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) != GLFW_PRESS)
        return false;

    glm::vec2 mouse;
    if (!getVirtualMouse(mouse)) return false;

    glm::vec2 diff = mouse - position;

    float c = std::cos(-rotation);
    float s = std::sin(-rotation);
    glm::vec2 local;
    local.x = diff.x * c - diff.y * s;
    local.y = diff.x * s + diff.y * c;

    float halfW = scale.x * 0.5f;
    float halfH = scale.y * 0.5f;

    return std::abs(local.x) <= halfW && std::abs(local.y) <= halfH;
}

bool TextureButton::is_click() {
    GLFWwindow* window = glfwGetCurrentContext();
    if (!window) return false;

    glm::vec2 mouse;
    bool inside = getVirtualMouse(mouse);

    bool hovered = false;
    if (inside) {
        glm::vec2 diff = mouse - position;

        float c = std::cos(-rotation);
        float s = std::sin(-rotation);
        glm::vec2 local;
        local.x = diff.x * c - diff.y * s;
        local.y = diff.x * s + diff.y * c;

        float halfW = scale.x * 0.5f;
        float halfH = scale.y * 0.5f;

        hovered = std::abs(local.x) <= halfW && std::abs(local.y) <= halfH;
    }

    bool pressed = glfwGetMouseButton(window, GLFW_MOUSE_BUTTON_LEFT) == GLFW_PRESS;
    bool clicked = pressed && !prevPressed && hovered;
    prevPressed = pressed;

    return clicked;
}

void TextureButton::show() {
    if (visible != true) {
     visible = true;
    }
}

void TextureButton::hide() {
    if (visible != false) {
     visible = false;
    }
}