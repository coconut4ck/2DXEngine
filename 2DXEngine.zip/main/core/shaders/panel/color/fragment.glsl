#version 330 core

in vec3 vColor;
out vec4 FragColor;

uniform vec3 uColor;
uniform float alpha;


void main() {
    FragColor = vec4(uColor, alpha);
}