#version 330 core

in vec2 vUV;
out vec4 FragColor;

uniform sampler2D uTexture;
uniform vec3 uTint;
uniform float alpha;

void main() {
    vec4 tex = texture(uTexture, vUV);
    FragColor = vec4(tex.rgb * uTint, tex.a * alpha);
}