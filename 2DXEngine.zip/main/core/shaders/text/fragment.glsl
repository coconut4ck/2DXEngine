#version 330 core

in vec2 vTexCoord;
out vec4 FragColor;

uniform sampler2D uTexture;
uniform vec3 uTint;
uniform float alpha;

void main() {
    float modulate = texture(uTexture, vTexCoord).r;
    FragColor = vec4(uTint, modulate * alpha);
}