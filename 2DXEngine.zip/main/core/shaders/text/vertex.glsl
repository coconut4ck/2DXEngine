#version 330 core

layout(location = 0) in vec4 aVertex;

uniform mat4 uProjection;
uniform mat4 uModel;

out vec2 vTexCoord;

void main() {
    vTexCoord = aVertex.zw;
    gl_Position = uProjection * uModel * vec4(aVertex.xy, 0.0, 1.0);
}