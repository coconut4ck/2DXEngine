#pragma once
#include <string>
#include <vector>

class Scene {
public:
    virtual ~Scene() = default;

    virtual const char* name() const { return "Scene"; }
    virtual void onEnter() {}
    virtual void onExit() {}
    virtual void onUpdate(float dt) {}
    virtual void onDraw() {}
};

class SceneManager {
public:
    static SceneManager& instance();

    void add(Scene* s);
    void remove(Scene* s);

    void switchTo(const std::string& name);
    void start();
    void start_with(const std::string& name);

    Scene* current() const { return active; }

    void update(float dt);
    void draw();

    void quit();
    bool quited = false;
private:
    SceneManager() = default;
    SceneManager(const SceneManager&) = delete;
    SceneManager& operator=(const SceneManager&) = delete;

    std::vector<Scene*> scenes;
    Scene* active = nullptr;
};

template <typename T>
class SceneRegistrar {
public:
    SceneRegistrar() {
        instance = new T();
        SceneManager::instance().add(instance);
    }
    ~SceneRegistrar() {
        SceneManager::instance().remove(instance);
        delete instance;
    }
private:
    T* instance = nullptr;
};

#define REGISTER_SCENE(Type) \
    static SceneRegistrar<Type> _scene_registrar_##Type;