#include "scene.h"
#include <algorithm>

SceneManager& SceneManager::instance() {
    static SceneManager mgr;
    return mgr;
}

void SceneManager::add(Scene* s) {
    if (s) scenes.push_back(s);
}

void SceneManager::remove(Scene* s) {
    scenes.erase(std::remove(scenes.begin(), scenes.end(), s), scenes.end());
    if (active == s) active = nullptr;
}

void SceneManager::switchTo(const std::string& name) {
    if (active && name == active->name()) return;
    for (Scene* s : scenes) {
        if (name == s->name()) {
            if (active) active->onExit();
            active = s;
            active->onEnter();
            return;
        }
    }
}

void SceneManager::start() {
    if (!active && !scenes.empty()) {
        active = scenes.front();
        active->onEnter();
    }
}

void SceneManager::start_with(const std::string& name) {
    for (Scene* s : scenes) {
        if (name == s->name()) {
            if (active) active->onExit();
            active = s;
            active->onEnter();
            return;
        }
    }
}

void SceneManager::update(float dt) {
    if (active) active->onUpdate(dt);
}

void SceneManager::draw() {
    if (active) active->onDraw();
}

void SceneManager::quit() {
    if (quited == false) {
        quited = true;
    }
}