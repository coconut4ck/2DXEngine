#include <core/other/shader.h>

#include <core/ui/panel/color/color_panel.h>
#include <core/ui/panel/texture/texture_panel.h>
#include <core/ui/panel/shader/shader_panel.h>
#include "core/ui/text/text.h"
#include "core/ui/button/color/color_button.h"
#include "core/ui/button/texture/texture_button.h"

#include "core/plugins/FpsCounter/FpsCounter.h"
#include "core/plugins/DeltaTime/DeltaTime.h"
#include "core/plugins/Sound/Sound.h"
#include "core/plugins/Timer/Timer.h"
#include "core/plugins/Random/Random.h"

#include "core/main/scenes/scene.h"

#include "core/main/settings.h"