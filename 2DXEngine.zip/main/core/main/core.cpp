#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <algorithm>

#include "settings.h"
#include "scripts/script.h"
#include <core/other/shader.h>
#include <core/main/scenes/scene.h>

int main() {
    Settings win_settings;

    if (!glfwInit()) { std::cerr << "GLFW init failed\n"; return -1; }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    if (win_settings.fullscreen) {
        win_settings.applyMonitorResolution();
    }

    GLFWmonitor* monitor = win_settings.fullscreen ? glfwGetPrimaryMonitor() : nullptr;

    GLFWwindow* window = glfwCreateWindow(
        win_settings.width, win_settings.height,
        win_settings.title, monitor, nullptr);
    if (!window) { glfwTerminate(); return -1; }

    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "GLAD init failed\n"; return -1;
    }

    const float VIRTUAL_W = win_settings.v_width;
    const float VIRTUAL_H = win_settings.v_height;
    const float VIRTUAL_ASPECT = VIRTUAL_W / VIRTUAL_H;

    glm::mat4 proj = glm::ortho(
        0.0f, VIRTUAL_W,
        VIRTUAL_H, 0.0f,
        -1.0f, 1.0f);

    Shader::setProjection(proj);

    ScriptRegistry::instance().callReady();

    SceneManager::instance().start_with(win_settings.main_scene);

    float lastTime = (float)glfwGetTime();

    bool lastFullscreen = win_settings.fullscreen;
    int savedX = 100, savedY = 100;
    int savedW = win_settings.width;
    int savedH = win_settings.height;

    while (!glfwWindowShouldClose(window)) {
        glfwPollEvents();

        if (win_settings.fullscreen != lastFullscreen) {
            lastFullscreen = win_settings.fullscreen;

            if (win_settings.fullscreen) {
                glfwGetWindowPos(window, &savedX, &savedY);
                glfwGetWindowSize(window, &savedW, &savedH);

                GLFWmonitor* mon = glfwGetPrimaryMonitor();
                const GLFWvidmode* mode = glfwGetVideoMode(mon);

                win_settings.width  = mode->width;
                win_settings.height = mode->height;

                glfwSetWindowMonitor(window, mon,
                                    0, 0, mode->width, mode->height, mode->refreshRate);
            } else {
                win_settings.width  = savedW;
                win_settings.height = savedH;

                glfwSetWindowMonitor(window, nullptr,
                                    savedX, savedY, savedW, savedH, 0);
            }
        }

        int fbW, fbH;
        glfwGetFramebufferSize(window, &fbW, &fbH);

        if (fbW == 0 || fbH == 0) {
            glfwWaitEvents();
            continue;
        }

        float windowAspect = (float)fbW / (float)fbH;

        int vpX, vpY, vpW, vpH;

        if (windowAspect > VIRTUAL_ASPECT) {
            vpH = fbH;
            vpW = (int)(fbH * VIRTUAL_ASPECT);
            vpX = (fbW - vpW) / 2;
            vpY = 0;
        } else {
            vpW = fbW;
            vpH = (int)(fbW / VIRTUAL_ASPECT);
            vpX = 0;
            vpY = (fbH - vpH) / 2;
        }

        glViewport(vpX, vpY, vpW, vpH);

        float now = (float)glfwGetTime();
        float dt = now - lastTime;
        lastTime = now;

        glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT);

        ScriptRegistry::instance().callUpdate(dt);
        SceneManager::instance().update(dt);

        ScriptRegistry::instance().callDraw();
        SceneManager::instance().draw();

        glfwSwapBuffers(window);

        if (SceneManager::instance().quited == true) break;
    }

    ScriptRegistry::instance().callQuit();

    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}