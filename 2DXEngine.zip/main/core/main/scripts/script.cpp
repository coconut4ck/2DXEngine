#include "script.h"
#include <algorithm>

ScriptRegistry& ScriptRegistry::instance() {
    static ScriptRegistry reg;
    return reg;
}

void ScriptRegistry::add(Script* s) {
    if (s) scripts.push_back(s);
}

void ScriptRegistry::remove(Script* s) {
    scripts.erase(std::remove(scripts.begin(), scripts.end(), s), scripts.end());
}

void ScriptRegistry::callReady() {
    for (auto* s : scripts) s->onReady();
}

void ScriptRegistry::callUpdate(float dt) {
    for (auto* s : scripts) s->onUpdate(dt);
}

void ScriptRegistry::callDraw() {
    for (auto* s : scripts) s->onDraw();
}

void ScriptRegistry::callQuit() {
    for (auto* s : scripts) s->onQuit();
}