#pragma once
#include <vector>
#include <string>

class Script {
public:
    virtual ~Script() = default;

    virtual const char* name() const { return "Script"; }
    virtual void onReady() {}
    virtual void onUpdate(float dt) {}
    virtual void onDraw() {}
    virtual void onQuit() {}
};

class ScriptRegistry {
public:
    static ScriptRegistry& instance();

    void add(Script* s);
    void remove(Script* s);

    const std::vector<Script*>& all() const { return scripts; }

    void callReady();
    void callUpdate(float dt);
    void callDraw();
    void callQuit();

private:
    ScriptRegistry() = default;
    std::vector<Script*> scripts;
};

template <typename T>
class ScriptRegistrar {
public:
    ScriptRegistrar() {
        instance = new T();
        ScriptRegistry::instance().add(instance);
    }
    ~ScriptRegistrar() {
        ScriptRegistry::instance().remove(instance);
        delete instance;
    }
private:
    T* instance = nullptr;
};

#define REGISTER_SCRIPT(Type) \
    static ScriptRegistrar<Type> _script_registrar_##Type;