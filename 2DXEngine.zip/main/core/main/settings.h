#pragma once

#include <iostream>
#include <GLFW/glfw3.h>
using namespace std;

class Settings {
public:
    const char* title = "New project";

    int width = 1152;
    int height = 648;
    int v_width = 1152;
    int v_height = 648;

    bool fullscreen =  false;


    const char* main_scene = "";


    void applyMonitorResolution() {
        GLFWmonitor* monitor = glfwGetPrimaryMonitor();
        if (!monitor) return;

        const GLFWvidmode* mode = glfwGetVideoMode(monitor);
        if (!mode) return;

        width  = mode->width;
        height = mode->height;
    }
};