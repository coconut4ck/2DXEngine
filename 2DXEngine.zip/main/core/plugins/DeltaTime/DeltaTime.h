#pragma once

class DeltaTime {
public:
    DeltaTime() = default;
    ~DeltaTime() = default;

    float get_delta();
    float get_physic_delta();
private:
    double lastTime = 0.0;
    bool inited = false;
};