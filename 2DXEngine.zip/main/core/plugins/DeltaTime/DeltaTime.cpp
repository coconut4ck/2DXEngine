#include "DeltaTime.h"
#include <GLFW/glfw3.h>

float DeltaTime::get_delta() {
    double currentTime = glfwGetTime();

    if (!inited) {
        lastTime = currentTime;
        inited = true;
        return 0.0f;
    }

    float deltaTime = static_cast<float>(currentTime - lastTime);
    lastTime = currentTime;

    return deltaTime;
}

float DeltaTime::get_physic_delta() {
    return 0.00694f;
}