#include "FpsCounter.h"
#include <cstring>

float FpsCounter::get_fps_float(const float ti) {
    hide_fps += 1.0f;
    accum += delta.get_delta();

    if (accum >= ti) {
        show_fps = hide_fps / accum;
        hide_fps = 0.0f;
        accum    = 0.0f;
    }
    
    return show_fps;
}

int FpsCounter::get_fps_int(const float ti) {
    hide_fps += 1.0f;
    accum += delta.get_delta();

    if (accum >= ti) {
        show_fps = hide_fps / accum;
        hide_fps = 0.0f;
        accum    = 0.0f;
    }
    
    return show_fps;
}