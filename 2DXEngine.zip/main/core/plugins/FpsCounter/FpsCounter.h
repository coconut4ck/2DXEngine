#pragma once
#include "core/plugins/DeltaTime/DeltaTime.h"

class FpsCounter {
public:
    FpsCounter() = default;
    ~FpsCounter() = default;

    float get_fps_float(const float ti = 1.0f);
    int get_fps_int(const float ti = 1.0f);

private:
    float hide_fps = 0.0f;
    float show_fps = 0.0f;
    float accum = 0.0f;
    bool inited = false;

    DeltaTime delta;
};