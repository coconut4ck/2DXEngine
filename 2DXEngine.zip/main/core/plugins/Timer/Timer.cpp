#include "Timer.h"


void Timer::start(const float seconds, const bool loop) {
    timer = seconds;
    startTime = seconds;
    looping = loop;
    isFinished = false;
    running = true;
}

void Timer::stop() {
    timer = 0.0f;
    isFinished = false;
    running = false;
}

void Timer::update(const float delta) {
    if (!running || (isFinished && !looping)) return;

    timer -= delta;

    if (timer <= 0.0f) {
        if (looping) {
            timer = startTime;
        } else {
            timer = 0.0f;
            isFinished = true;
            running = false;
        }
    }
}

bool Timer::finished() {
    return isFinished;
}

float Timer::get_current_time() {
    return timer;
}

void Timer::set_start_time(const float seconds) {
    startTime = seconds;
}