#pragma once

class Timer {
public:
    Timer() = default;
    ~Timer() = default;

    void start(const float seconds = 1.0f, const bool loop = false);
    void stop();
    void update(const float delta = 0.00694f);
    float get_current_time();
    bool finished();
    void set_start_time(const float seconds);

private:
    float timer = 0.0f;
    float startTime = 0.0f;
    bool  isFinished = false;
    bool  looping = false;
    bool  running = false;
};