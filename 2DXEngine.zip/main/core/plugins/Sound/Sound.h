#pragma once

#include "miniaudio.h"

class Sound {
public:
    Sound() = default;
    ~Sound() { stop(); }

    void play(const char* path, const bool loop, const bool one = false);
    void stop();

private:
    ma_sound m_sound{};
    bool m_initialized = false;
    bool started = false;
    const char* current_path = "";
};