#include "Sound.h"

#define MINIAUDIO_IMPLEMENTATION
#include "miniaudio.h"


void Sound::play(const char* path, const bool loop, const bool one) {
    if (one && m_initialized && ma_sound_is_playing(&m_sound) and path == current_path) {
        return;
    }

    stop();

    current_path = path;

    static ma_engine engine;
    static bool engineInitialized = false;
    if (!engineInitialized) {
        if (ma_engine_init(nullptr, &engine) != MA_SUCCESS) {
            return;
        }
        engineInitialized = true;
    }

    if (ma_sound_init_from_file(&engine, path, 0, nullptr, nullptr, &m_sound) != MA_SUCCESS) {
        return;
    }

    m_initialized = true;

    ma_sound_set_looping(&m_sound, loop ? MA_TRUE : MA_FALSE);
    ma_sound_start(&m_sound);
}

void Sound::stop() {
    if (!m_initialized) {
        return;
    }

    current_path = "";

    ma_sound_stop(&m_sound);
    ma_sound_uninit(&m_sound);
    m_initialized = false;
    started = false;
}