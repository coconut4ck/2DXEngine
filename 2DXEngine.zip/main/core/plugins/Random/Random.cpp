#include "Random.h"

int Random::random_int(const int a, const int b) {
    std::uniform_int_distribution<int> dist(a, b);
    return dist(gen);
}

float Random::random_float(const float a, const float b) {
    std::uniform_real_distribution<float> dist(a, b);
    return dist(gen);
}

bool Random::random_bool() {
    std::uniform_int_distribution<int> dist(0, 1);
    bool current_bool = dist(gen);
    if (current_bool == 0) {
        return false;
    } else {
        return true;
    }
}