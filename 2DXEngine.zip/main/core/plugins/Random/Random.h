#pragma once
#include <random>

class Random {
public:
    Random() : gen(std::random_device{}()) {}
    ~Random() = default;

    float random_float(float a = 0.0f, float b = 1.0f);
    int random_int(int a = 0, int b = 1);
    bool random_bool();
private:
    std::mt19937 gen;
};