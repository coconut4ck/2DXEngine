#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <string>
#include <map>
#include <memory>

class Shader {
public:
    unsigned int ID = 0;

    Shader() = default;
    Shader(const char* vertexPath, const char* fragmentPath);
    ~Shader();

    void use() const;
    void destroy();

    void setMat4(const char* name, const glm::mat4& mat) const;
    void setVec3(const char* name, const glm::vec3& v) const;
    void setVec4(const char* name, const glm::vec4& v) const;
    void setFloat(const char* name, float v) const;
    void setInt(const char* name, int v) const;

    static void setProjection(const glm::mat4& m) { s_projection = m; }
    static const glm::mat4& projection() { return s_projection; }

private:
    static unsigned int compile(unsigned int type, const std::string& src);

    static glm::mat4 s_projection;
};


class ShaderCache {
public:
    static Shader* get(const char* vs, const char* fs) {
        static std::map<std::string, std::unique_ptr<Shader>> cache;
        std::string key = std::string(vs) + "|" + fs;
        auto it = cache.find(key);
        if (it != cache.end()) return it->second.get();
        auto s = std::make_unique<Shader>(vs, fs);
        Shader* raw = s.get();
        cache[key] = std::move(s);
        return raw;
    }
};