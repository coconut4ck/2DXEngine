#include "shader.h"
#include <fstream>
#include <sstream>
#include <iostream>

glm::mat4 Shader::s_projection = glm::mat4(1.0f);

static std::string readFile(const char* path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        std::cerr << "Failed to open shader: " << path << "\n";
        return {};
    }
    std::stringstream ss;
    ss << file.rdbuf();
    return ss.str();
}

unsigned int Shader::compile(unsigned int type, const std::string& src) {
    unsigned int id = glCreateShader(type);
    const char* csrc = src.c_str();
    glShaderSource(id, 1, &csrc, nullptr);
    glCompileShader(id);

    int ok;
    glGetShaderiv(id, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetShaderInfoLog(id, 1024, nullptr, log);
        std::cerr << "Shader compile error: " << log << "\n";
    }
    return id;
}

Shader::Shader(const char* vertexPath, const char* fragmentPath) {
    std::string vsrc = readFile(vertexPath);
    std::string fsrc = readFile(fragmentPath);

    unsigned int vs = compile(GL_VERTEX_SHADER, vsrc);
    unsigned int fs = compile(GL_FRAGMENT_SHADER, fsrc);

    ID = glCreateProgram();
    glAttachShader(ID, vs);
    glAttachShader(ID, fs);
    glLinkProgram(ID);

    int ok;
    glGetProgramiv(ID, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[1024];
        glGetProgramInfoLog(ID, 1024, nullptr, log);
        std::cerr << "Program link error: " << log << "\n";
    }

    glDeleteShader(vs);
    glDeleteShader(fs);
}

Shader::~Shader() {
    if (ID) glDeleteProgram(ID);
}

void Shader::use() const {
    glUseProgram(ID);
    setMat4("uProjection", s_projection);
}

void Shader::destroy() {
    if (ID) { glDeleteProgram(ID); ID = 0; }
}

void Shader::setMat4(const char* name, const glm::mat4& mat) const {
    glUniformMatrix4fv(glGetUniformLocation(ID, name), 1, GL_FALSE, &mat[0][0]);
}

void Shader::setVec3(const char* name, const glm::vec3& v) const {
    glUniform3fv(glGetUniformLocation(ID, name), 1, &v[0]);
}

void Shader::setVec4(const char* name, const glm::vec4& v) const {
    glUniform4fv(glGetUniformLocation(ID, name), 1, &v[0]);
}

void Shader::setFloat(const char* name, float v) const {
    glUniform1f(glGetUniformLocation(ID, name), v);
}

void Shader::setInt(const char* name, int v) const {
    glUniform1i(glGetUniformLocation(ID, name), v);
}