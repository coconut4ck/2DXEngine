#pragma once
#include <glad/glad.h>

class Mesh {
public:
    unsigned int VAO = 0, VBO = 0, EBO = 0;
    int indexCount = 0;

    Mesh() = default;
    ~Mesh();

    void create(const float* vertices, int vertexCount,
                const unsigned int* indices, int indexCount_);
    void draw() const;
    void destroy();
};