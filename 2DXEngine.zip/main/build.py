from PyInstaller.__main__ import run

if __name__ == '__main__':
    opts = [
        'editor.py',
        '--onefile',
        '--name=2DXEngine',
        # '--icon=icon.ico',
        '--noconsole',
        # '--uac-admin',
    ]

    run(opts)