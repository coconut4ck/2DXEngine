import sys
import os
import re
import json
import shutil
import subprocess
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPlainTextEdit, QTextEdit, QFileDialog, QMessageBox, QLabel,
    QStatusBar, QAction, QSplitter, QTreeView, QFileSystemModel,
    QPushButton, QShortcut, QTextBrowser, QFrame, QStyleFactory,
    QTabWidget, QMenu, QInputDialog, QLineEdit, QToolButton, QTabBar,
    QDialog, QFormLayout, QDialogButtonBox, QCheckBox, QSpinBox,
    QGroupBox, QComboBox
)
from PyQt5.QtCore import Qt, QRect, QSize, QRegularExpression, QDir, QModelIndex, QPoint, QProcess
from PyQt5.QtGui import (
    QFont, QColor, QPainter, QTextFormat, QTextCursor,
    QKeySequence, QSyntaxHighlighter, QTextCharFormat
)

LAST_PROJECT_FILE = os.path.join(os.path.expanduser("~"), ".2dxengine_last_project.json")


def save_last_project(folder):
    try:
        with open(LAST_PROJECT_FILE, "w", encoding="utf-8") as f:
            json.dump({"path": folder}, f, ensure_ascii=False)
    except Exception:
        pass


def load_last_project():
    if not os.path.isfile(LAST_PROJECT_FILE):
        return None
    try:
        with open(LAST_PROJECT_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            path = data.get("path")
            if path and os.path.isdir(path) and os.path.isfile(os.path.join(path, "project.2dxp")):
                return path
    except Exception:
        pass
    return None


def get_core_source_dir():
    base = os.path.dirname(os.path.abspath(sys.argv[0]))
    core = os.path.join(base, "core")
    if os.path.isdir(core):
        return core
    if getattr(sys, 'frozen', False):
        core = os.path.join(os.path.dirname(sys.executable), "core")
        if os.path.isdir(core):
            return core
    return None


def get_build_bat_path():
    base = os.path.dirname(os.path.abspath(sys.argv[0]))
    build_dir = os.path.join(base, "build")
    bat = os.path.join(build_dir, "build.bat")
    if os.path.isfile(bat):
        return bat
    if getattr(sys, 'frozen', False):
        build_dir = os.path.join(os.path.dirname(sys.executable), "build")
        bat = os.path.join(build_dir, "build.bat")
        if os.path.isfile(bat):
            return bat
    return None


def read_project_json(folder):
    if not folder:
        return {}
    p = os.path.join(folder, "project.2dxp")
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def write_project_json(folder, data):
    p = os.path.join(folder, "project.2dxp")
    with open(p, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


class SettingsDialog(QDialog):
    def __init__(self, parent, settings_path, build_data=None):
        super().__init__(parent)
        self.settings_path = settings_path
        self.build_data = build_data or {}
        self.setWindowTitle("Project Settings")
        self.setMinimumWidth(520)
        self._build_ui()
        self._load_settings()
        self._load_build_settings()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        layout.addWidget(tabs)

        proj_tab = QWidget()
        proj_layout = QFormLayout(proj_tab)
        proj_layout.setLabelAlignment(Qt.AlignRight)

        self.title_edit = QLineEdit()
        proj_layout.addRow("title:", self.title_edit)

        self.width_spin = QSpinBox()
        self.width_spin.setRange(1, 100000)
        proj_layout.addRow("width:", self.width_spin)

        self.height_spin = QSpinBox()
        self.height_spin.setRange(1, 100000)
        proj_layout.addRow("height:", self.height_spin)

        self.v_width_spin = QSpinBox()
        self.v_width_spin.setRange(1, 100000)
        proj_layout.addRow("v_width:", self.v_width_spin)

        self.v_height_spin = QSpinBox()
        self.v_height_spin.setRange(1, 100000)
        proj_layout.addRow("v_height:", self.v_height_spin)

        self.fullscreen_check = QCheckBox()
        proj_layout.addRow("fullscreen:", self.fullscreen_check)

        self.main_scene_edit = QLineEdit()
        proj_layout.addRow("main_scene:", self.main_scene_edit)

        tabs.addTab(proj_tab, "Project")

        build_tab = QWidget()
        build_layout = QFormLayout(build_tab)
        build_layout.setLabelAlignment(Qt.AlignRight)

        self.save_before_build_check = QCheckBox()
        self.save_before_build_check.setChecked(True)
        build_layout.addRow("Save project before build:", self.save_before_build_check)

        self.vcpkg_path_edit = QLineEdit()
        build_layout.addRow("VCPKG path:", self.vcpkg_path_edit)

        self.clang_path_edit = QLineEdit()
        build_layout.addRow("clang-cl path:", self.clang_path_edit)

        self.cpp_std_combo = QComboBox()
        self.cpp_std_combo.addItems(["c++14", "c++17", "c++20", "c++23"])
        build_layout.addRow("C++ standard:", self.cpp_std_combo)

        self.output_name_edit = QLineEdit()
        build_layout.addRow("Output exe name:", self.output_name_edit)

        self.subsystem_combo = QComboBox()
        self.subsystem_combo.addItems(["WINDOWS", "CONSOLE"])
        build_layout.addRow("Subsystem:", self.subsystem_combo)

        self.extra_libs_edit = QLineEdit()
        build_layout.addRow("Extra libs:", self.extra_libs_edit)

        self.extra_includes_edit = QLineEdit()
        build_layout.addRow("Extra includes:", self.extra_includes_edit)

        self.launch_after_build_check = QCheckBox()
        self.launch_after_build_check.setChecked(True)
        build_layout.addRow("Launch after build:", self.launch_after_build_check)

        self.log_output_check = QCheckBox()
        self.log_output_check.setChecked(True)
        build_layout.addRow("Show build output:", self.log_output_check)

        tabs.addTab(build_tab, "Build")

        buttons = QDialogButtonBox(QDialogButtonBox.Save | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._save_settings)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _load_settings(self):
        if not os.path.isfile(self.settings_path):
            QMessageBox.warning(self, "Error", f"settings.h not found:\n{self.settings_path}")
            self.reject()
            return
        try:
            with open(self.settings_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to read settings:\n{e}")
            self.reject()
            return

        def extract_str(name, default=""):
            m = re.search(r'const\s+char\s*\*\s*' + re.escape(name) + r'\s*=\s*"([^"]*)"', content)
            return m.group(1) if m else default

        def extract_int(name, default=0):
            m = re.search(r'\b' + re.escape(name) + r'\s*=\s*(-?\d+)', content)
            return int(m.group(1)) if m else default

        def extract_bool(name, default=False):
            m = re.search(r'\b' + re.escape(name) + r'\s*=\s*(true|false)', content)
            return (m.group(1) == "true") if m else default

        self.title_edit.setText(extract_str("title", "New project"))
        self.width_spin.setValue(extract_int("width", 1152))
        self.height_spin.setValue(extract_int("height", 648))
        self.v_width_spin.setValue(extract_int("v_width", 1152))
        self.v_height_spin.setValue(extract_int("v_height", 648))
        self.fullscreen_check.setChecked(extract_bool("fullscreen", False))
        self.main_scene_edit.setText(extract_str("main_scene", ""))

    def _load_build_settings(self):
        b = self.build_data
        self.save_before_build_check.setChecked(bool(b.get("save_before_build", True)))
        self.vcpkg_path_edit.setText(str(b.get("vcpkg_path", "C:\\vcpkg\\installed\\x64-windows")))
        self.clang_path_edit.setText(str(b.get("clang_path", "clang-cl.exe")))
        std = str(b.get("cpp_std", "c++17"))
        idx = self.cpp_std_combo.findText(std)
        if idx >= 0:
            self.cpp_std_combo.setCurrentIndex(idx)
        self.output_name_edit.setText(str(b.get("output_name", "Caretaker.exe")))
        sub = str(b.get("subsystem", "WINDOWS"))
        idx = self.subsystem_combo.findText(sub)
        if idx >= 0:
            self.subsystem_combo.setCurrentIndex(idx)
        self.extra_libs_edit.setText(str(b.get("extra_libs", "user32.lib gdi32.lib")))
        self.extra_includes_edit.setText(str(b.get("extra_includes", "")))
        self.launch_after_build_check.setChecked(bool(b.get("launch_after_build", True)))
        self.log_output_check.setChecked(bool(b.get("log_output", True)))

    def _save_settings(self):
        try:
            with open(self.settings_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to read settings:\n{e}")
            return

        def repl_str(name, value):
            nonlocal content
            pattern = re.compile(
                r'(const\s+char\s*\*\s*' + re.escape(name) + r'\s*=\s*")([^"]*)(")'
            )
            if not pattern.search(content):
                return False
            content = pattern.sub(lambda m: m.group(1) + value + m.group(3), content, count=1)
            return True

        def repl_int(name, value):
            nonlocal content
            pattern = re.compile(
                r'(\b' + re.escape(name) + r'\s*=\s*)(-?\d+)'
            )
            if not pattern.search(content):
                return False
            content = pattern.sub(lambda m: m.group(1) + str(value), content, count=1)
            return True

        def repl_bool(name, value):
            nonlocal content
            pattern = re.compile(
                r'(\b' + re.escape(name) + r'\s*=\s*)(true|false)'
            )
            if not pattern.search(content):
                return False
            v = "true" if value else "false"
            content = pattern.sub(lambda m: m.group(1) + v, content, count=1)
            return True

        title = self.title_edit.text().replace('"', '\\"')
        repl_str("title", title)
        repl_int("width", self.width_spin.value())
        repl_int("height", self.height_spin.value())
        repl_int("v_width", self.v_width_spin.value())
        repl_int("v_height", self.v_height_spin.value())
        repl_bool("fullscreen", self.fullscreen_check.isChecked())
        repl_str("main_scene", self.main_scene_edit.text().replace('"', '\\"'))

        try:
            with open(self.settings_path, "w", encoding="utf-8") as f:
                f.write(content)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save settings:\n{e}")
            return

        self._collect_build_settings()
        self.accept()

    def _collect_build_settings(self):
        self.build_data = {
            "save_before_build": self.save_before_build_check.isChecked(),
            "vcpkg_path": self.vcpkg_path_edit.text(),
            "clang_path": self.clang_path_edit.text(),
            "cpp_std": self.cpp_std_combo.currentText(),
            "output_name": self.output_name_edit.text(),
            "subsystem": self.subsystem_combo.currentText(),
            "extra_libs": self.extra_libs_edit.text(),
            "extra_includes": self.extra_includes_edit.text(),
            "launch_after_build": self.launch_after_build_check.isChecked(),
            "log_output": self.log_output_check.isChecked(),
        }

    def get_build_settings(self):
        return self.build_data


class SyntaxHighlighter(QSyntaxHighlighter):
    def __init__(self, parent, language="2dxf"):
        super().__init__(parent)
        self.language = language
        self.rules = []
        self.setup_rules(language)

    def setup_rules(self, language):
        self.rules = []
        lang = language.lower()
        if lang == "2dxf":
            self._setup_2dxf()
        elif lang in ("cpp", "c", "h", "hpp"):
            self._setup_cpp()
        elif lang == "json":
            self._setup_json()
        elif lang == "python":
            self._setup_python()
        elif lang == "js":
            self._setup_js()
        elif lang in ("html", "xml"):
            self._setup_html()
        elif lang == "css":
            self._setup_css()
        elif lang in ("md", "markdown"):
            self._setup_markdown()
        else:
            self._setup_generic()

    def _setup_2dxf(self):
        self.add_rule(['and', 'or', 'not', 'true', 'false', 'nil', 'null'], "#E06C75", bold=True)
        self.add_rule(['make', 'var', 'func', 'return', 'break', 'continue', 'yield', 'async', 'await', 'static', 'const'], "#C678DD", bold=True)
        self.add_rule(['math', 'root', 'roundUp', 'roundDown', 'random', 'degree', 'module', 'abs', 'min', 'max', 'clamp', 'lerp', 'floor', 'ceil', 'sin', 'cos', 'tan', 'sqrt', 'pow'], "#56B6C2", bold=True)
        self.add_rule(['say', 'stick', 'ask', 'input', 'print', 'debug', 'warn', 'error'], "#48C9B0")
        self.add_rule(['number', 'float', 'string', 'logic', 'bool', 'int', 'void', 'array', 'object', 'any'], "#98C379")
        self.add_rule(['loopFor', 'loopWhile', 'if', 'elif', 'else', 'start', 'end', 'class', 'struct', 'enum', 'try', 'catch', 'throw', 'switch', 'case', 'default'], "#E5C07B", bold=True)
        self.add_rule(['import', 'export', 'from', 'as', 'module', 'include'], "#D19A66", bold=True)
        self.add_rule(['self', 'this', 'super', 'base'], "#E06C75", italic=True)
        self.add_rule(['entity', 'component', 'scene', 'system', 'update', 'render', 'init'], "#61AFEF", bold=True)
        self.add_pattern(r'\b[0-9]+\b', "#99F0FF")
        self.add_pattern(r'\b[0-9]+\.[0-9]+\b', "#99F0FF")
        self.add_pattern(r'\b0[xX][0-9a-fA-F]+\b', "#99F0FF")
        self.add_pattern(r'"[^"\\]*(\\.[^"\\]*)*"', "#D4A057")
        self.add_pattern(r"'[^'\\]*(\\.[^'\\]*)*'", "#D4A057")
        self.add_pattern(r'//[^\n]*', "#6A9955", italic=True)
        self.add_pattern(r'@\w+', "#D19A66")
        self.add_pattern(r'\b[A-Za-z_]\w*(?=\s*\()', "#61AFEF")

    def _setup_cpp(self):
        self.add_rule([
            'int', 'float', 'double', 'char', 'void', 'bool', 'long', 'short',
            'unsigned', 'signed', 'auto', 'size_t', 'wchar_t', 'char8_t',
            'char16_t', 'char32_t', 'int8_t', 'int16_t', 'int32_t', 'int64_t',
            'uint8_t', 'uint16_t', 'uint32_t', 'uint64_t'
        ], "#56B6C2", bold=True)
        self.add_rule([
            'class', 'struct', 'enum', 'union', 'namespace', 'template',
            'typename', 'public', 'private', 'protected', 'virtual', 'override',
            'static', 'const', 'constexpr', 'consteval', 'constinit', 'mutable',
            'volatile', 'extern', 'inline', 'explicit', 'friend', 'typedef',
            'using', 'new', 'delete', 'this', 'operator', 'final', 'decltype',
            'noexcept', 'static_cast', 'dynamic_cast', 'reinterpret_cast',
            'const_cast', 'alignas', 'alignof', 'static_assert', 'co_await',
            'co_return', 'co_yield', 'concept', 'requires', 'module', 'import'
        ], "#C678DD", bold=True)
        self.add_rule([
            'if', 'else', 'for', 'while', 'do', 'switch', 'case', 'default',
            'break', 'continue', 'return', 'goto', 'try', 'catch', 'throw'
        ], "#E5C07B", bold=True)
        self.add_rule(['true', 'false', 'nullptr', 'NULL'], "#E06C75", bold=True)
        self.add_rule(['std', 'cout', 'cin', 'cerr', 'endl', 'string', 'vector', 'map', 'set', 'shared_ptr', 'unique_ptr', 'weak_ptr', 'make_shared', 'make_unique'], "#48C9B0")
        self.add_pattern(r'#\s*\w+', "#D19A66")
        self.add_pattern(r'<[^>\n]+>', "#98C379")
        self.add_pattern(r'\b[A-Za-z_]\w*(?=\s*\()', "#61AFEF")
        self.add_pattern(r'\b0[xX][0-9a-fA-F]+\b', "#99F0FF")
        self.add_pattern(r'\b0[bB][01]+\b', "#99F0FF")
        self.add_pattern(r'\b[0-9]+\.?[0-9]*([eE][+-]?[0-9]+)?[fFlLuU]*\b', "#99F0FF")
        self.add_pattern(r'"(?:[^"\\]|\\.)*"', "#D4A057")
        self.add_pattern(r"'(?:[^'\\]|\\.)*'", "#D4A057")
        self.add_pattern(r'//[^\n]*', "#6A9955", italic=True)

    def _setup_python(self):
        self.add_rule([
            'def', 'class', 'return', 'if', 'elif', 'else', 'for', 'while',
            'break', 'continue', 'pass', 'import', 'from', 'as', 'try', 'except',
            'finally', 'raise', 'with', 'lambda', 'yield', 'global', 'nonlocal',
            'assert', 'del', 'in', 'is', 'not', 'and', 'or', 'async', 'await'
        ], "#C678DD", bold=True)
        self.add_rule(['True', 'False', 'None'], "#E06C75", bold=True)
        self.add_rule(['int', 'str', 'float', 'bool', 'list', 'dict', 'set', 'tuple', 'bytes', 'object'], "#56B6C2")
        self.add_rule(['print', 'len', 'range', 'enumerate', 'zip', 'map', 'filter', 'sum', 'min', 'max', 'abs', 'open', 'isinstance', 'type'], "#48C9B0")
        self.add_pattern(r'\b[A-Za-z_]\w*(?=\s*\()', "#61AFEF")
        self.add_pattern(r'\b[0-9]+\.?[0-9]*\b', "#99F0FF")
        self.add_pattern(r'[fFrRbBuU]?"(?:[^"\\]|\\.)*"', "#D4A057")
        self.add_pattern(r"[fFrRbBuU]?'(?:[^'\\]|\\.)*'", "#D4A057")
        self.add_pattern(r'#[^\n]*', "#6A9955", italic=True)
        self.add_pattern(r'@\w+', "#D19A66")

    def _setup_js(self):
        self.add_rule([
            'var', 'let', 'const', 'function', 'return', 'if', 'else', 'for',
            'while', 'do', 'switch', 'case', 'default', 'break', 'continue',
            'try', 'catch', 'finally', 'throw', 'new', 'delete', 'typeof',
            'instanceof', 'in', 'of', 'class', 'extends', 'super', 'this',
            'async', 'await', 'yield', 'import', 'export', 'from', 'as'
        ], "#C678DD", bold=True)
        self.add_rule(['true', 'false', 'null', 'undefined', 'NaN', 'Infinity'], "#E06C75", bold=True)
        self.add_rule(['console', 'document', 'window', 'Math', 'JSON', 'Array', 'Object', 'String', 'Number', 'Promise'], "#48C9B0")
        self.add_pattern(r'\b[A-Za-z_]\w*(?=\s*\()', "#61AFEF")
        self.add_pattern(r'\b[0-9]+\.?[0-9]*\b', "#99F0FF")
        self.add_pattern(r'`[^`]*`', "#D4A057")
        self.add_pattern(r'"(?:[^"\\]|\\.)*"', "#D4A057")
        self.add_pattern(r"'(?:[^'\\]|\\.)*'", "#D4A057")
        self.add_pattern(r'//[^\n]*', "#6A9955", italic=True)

    def _setup_html(self):
        self.add_pattern(r'</?[A-Za-z][\w-]*', "#569CD6")
        self.add_pattern(r'/?>', "#569CD6")
        self.add_pattern(r'\b[A-Za-z-]+(?==)', "#9CDCFE")
        self.add_pattern(r'"[^"]*"', "#CE9178")
        self.add_pattern(r"'[^']*'", "#CE9178")
        self.add_pattern(r'<!--[\s\S]*?-->', "#6A9955", italic=True)

    def _setup_css(self):
        self.add_pattern(r'[.#][\w-]+', "#D7BA7D")
        self.add_pattern(r'\b[a-z-]+(?=\s*:)', "#9CDCFE")
        self.add_pattern(r':[a-z-]+', "#569CD6")
        self.add_pattern(r'#[0-9a-fA-F]{3,8}\b', "#B5CEA8")
        self.add_pattern(r'"[^"]*"', "#CE9178")
        self.add_pattern(r"'[^']*'", "#CE9178")
        self.add_pattern(r'/\*[\s\S]*?\*/', "#6A9955", italic=True)

    def _setup_markdown(self):
        self.add_pattern(r'^#{1,6}\s.*$', "#569CD6", bold=True)
        self.add_pattern(r'\*\*[^*]+\*\*', "#D7BA7D", bold=True)
        self.add_pattern(r'\*[^*]+\*', "#D7BA7D", italic=True)
        self.add_pattern(r'`[^`]+`', "#CE9178")
        self.add_pattern(r'^\s*[-*+]\s', "#6796E6")
        self.add_pattern(r'\[[^\]]+\]\([^)]+\)', "#4EC9B0")

    def _setup_json(self):
        self.add_pattern(r'"[^"\\]*(?:\\.[^"\\]*)*"\s*(?=:)', "#9CDCFE")
        self.add_pattern(r'"[^"\\]*(?:\\.[^"\\]*)*"', "#CE9178")
        self.add_pattern(r'-?\b[0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?\b', "#B5CEA8")
        self.add_rule(['true', 'false', 'null'], "#569CD6", bold=True)

    def _setup_generic(self):
        self.add_pattern(r'\b[0-9]+\b', "#99F0FF")
        self.add_pattern(r'"[^"\\]*(\\.[^"\\]*)*"', "#D4A057")
        self.add_pattern(r"'[^'\\]*(\\.[^'\\]*)*'", "#D4A057")
        self.add_pattern(r'//[^\n]*', "#6A9955", italic=True)
        self.add_pattern(r'#[^\n]*', "#6A9955", italic=True)

    def add_rule(self, words, color, bold=False, italic=False):
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        if bold:
            fmt.setFontWeight(QFont.Bold)
        if italic:
            fmt.setFontItalic(True)
        for word in words:
            pattern = QRegularExpression(r'\b' + re.escape(word) + r'\b')
            self.rules.append((pattern, fmt))

    def add_pattern(self, pattern, color, bold=False, italic=False):
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        if bold:
            fmt.setFontWeight(QFont.Bold)
        if italic:
            fmt.setFontItalic(True)
        self.rules.append((QRegularExpression(pattern), fmt))

    def highlightBlock(self, text):
        for pattern, fmt in self.rules:
            matches = pattern.globalMatch(text)
            while matches.hasNext():
                match = matches.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), fmt)


class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor

    def sizeHint(self):
        return QSize(self.editor.line_width(), 0)

    def paintEvent(self, event):
        self.editor.paint_line_area(event)


class CodeEditor(QPlainTextEdit):
    def __init__(self):
        super().__init__()
        self.line_area = None
        self.highlighter = None
        self._setup_editor()

    def _setup_editor(self):
        font = QFont("Consolas", 11)
        font.setFixedPitch(True)
        self.setFont(font)
        self.line_area = LineNumberArea(self)
        self.set_language("2dxf")
        self.blockCountChanged.connect(self.update_line_width)
        self.updateRequest.connect(self.update_line_area)
        self.cursorPositionChanged.connect(self.highlight_line)
        self.update_line_width()
        self.highlight_line()
        self.setTabStopDistance(4 * self.fontMetrics().horizontalAdvance(' '))
        self.setLineWrapMode(QPlainTextEdit.NoWrap)

    def set_language(self, language):
        self.highlighter = SyntaxHighlighter(self.document(), language)

    def line_width(self):
        digits = len(str(max(1, self.blockCount())))
        return 10 + self.fontMetrics().horizontalAdvance('9') * digits

    def update_line_width(self):
        self.setViewportMargins(self.line_width(), 0, 0, 0)

    def update_line_area(self, rect, dy):
        if dy:
            self.line_area.scroll(0, dy)
        else:
            self.line_area.update(0, rect.y(), self.line_area.width(), rect.height())
        if rect.contains(self.viewport().rect()):
            self.update_line_width()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        cr = self.contentsRect()
        self.line_area.setGeometry(QRect(cr.left(), cr.top(), self.line_width(), cr.height()))

    def highlight_line(self):
        selections = []
        if not self.isReadOnly():
            sel = QTextEdit.ExtraSelection()
            sel.format.setBackground(QColor(38, 38, 38))
            sel.format.setProperty(QTextFormat.FullWidthSelection, True)
            sel.cursor = self.textCursor()
            sel.cursor.clearSelection()
            selections.append(sel)
        self.setExtraSelections(selections)

    def paint_line_area(self, event):
        painter = QPainter(self.line_area)
        painter.fillRect(event.rect(), QColor(37, 37, 38))
        block = self.firstVisibleBlock()
        num = block.blockNumber()
        top = self.blockBoundingGeometry(block).translated(self.contentOffset()).top()
        bottom = top + self.blockBoundingRect(block).height()
        current_line = self.textCursor().blockNumber()
        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                line_num = str(num + 1)
                if num == current_line:
                    painter.setPen(QColor(200, 200, 200))
                else:
                    painter.setPen(QColor(120, 120, 120))
                painter.drawText(0, int(top), self.line_area.width() - 6,
                                 self.fontMetrics().height(), Qt.AlignRight, line_num)
            block = block.next()
            top = bottom
            bottom = top + self.blockBoundingRect(block).height()
            num += 1

    def keyPressEvent(self, event):
        cursor = self.textCursor()
        text = event.text()
        pairs = {'"': '"', "'": "'", '(': ')', '[': ']', '{': '}'}

        if event.key() == Qt.Key_Tab:
            self.indent_selection()
            return
        if event.key() == Qt.Key_Backtab:
            self.unindent_selection()
            return

        if text in pairs and not event.modifiers() & (Qt.ControlModifier | Qt.AltModifier):
            if cursor.hasSelection():
                start = cursor.selectionStart()
                end = cursor.selectionEnd()
                cursor.beginEditBlock()
                cursor.setPosition(start)
                cursor.insertText(text)
                cursor.setPosition(end + 1)
                cursor.insertText(pairs[text])
                cursor.endEditBlock()
                cursor.setPosition(start + 1)
                cursor.setPosition(end + 1, QTextCursor.KeepAnchor)
                self.setTextCursor(cursor)
            else:
                cursor.beginEditBlock()
                cursor.insertText(text + pairs[text])
                cursor.endEditBlock()
                cursor.movePosition(QTextCursor.Left)
                self.setTextCursor(cursor)
            return

        if event.key() == Qt.Key_Return and not event.modifiers() & Qt.ShiftModifier:
            current_line = cursor.block().text()
            indent = len(current_line) - len(current_line.lstrip())
            stripped = current_line.rstrip()
            extra = 0
            if stripped.endswith('{') or stripped.endswith(':') or stripped.endswith('('):
                extra = 4
            cursor.beginEditBlock()
            cursor.insertText('\n' + ' ' * (indent + extra))
            cursor.endEditBlock()
            return

        super().keyPressEvent(event)

    def indent_selection(self):
        cursor = self.textCursor()
        if cursor.hasSelection():
            start = cursor.selectionStart()
            end = cursor.selectionEnd()
            cursor.setPosition(start)
            cursor.movePosition(QTextCursor.StartOfLine)
            start_block = cursor.blockNumber()
            cursor.setPosition(end)
            cursor.movePosition(QTextCursor.EndOfLine)
            end_block = cursor.blockNumber()
            cursor.beginEditBlock()
            for i in range(start_block, end_block + 1):
                cursor.movePosition(QTextCursor.Start)
                cursor.movePosition(QTextCursor.NextBlock, QTextCursor.MoveAnchor, i)
                cursor.movePosition(QTextCursor.StartOfLine)
                cursor.insertText('    ')
            cursor.endEditBlock()
        else:
            cursor.insertText('    ')

    def unindent_selection(self):
        cursor = self.textCursor()
        if cursor.hasSelection():
            start = cursor.selectionStart()
            end = cursor.selectionEnd()
            cursor.setPosition(start)
            cursor.movePosition(QTextCursor.StartOfLine)
            start_block = cursor.blockNumber()
            cursor.setPosition(end)
            cursor.movePosition(QTextCursor.EndOfLine)
            end_block = cursor.blockNumber()
            cursor.beginEditBlock()
            for i in range(start_block, end_block + 1):
                cursor.movePosition(QTextCursor.Start)
                cursor.movePosition(QTextCursor.NextBlock, QTextCursor.MoveAnchor, i)
                cursor.movePosition(QTextCursor.StartOfLine)
                text = cursor.block().text()
                if text.startswith('    '):
                    for _ in range(4):
                        cursor.deleteChar()
                elif text.startswith(' '):
                    cursor.deleteChar()
                elif text.startswith('\t'):
                    cursor.deleteChar()
            cursor.endEditBlock()
        else:
            cursor.movePosition(QTextCursor.StartOfLine)
            text = cursor.block().text()
            if text.startswith('    '):
                cursor.beginEditBlock()
                for _ in range(4):
                    cursor.deleteChar()
                cursor.endEditBlock()
            elif text.startswith(' '):
                cursor.beginEditBlock()
                cursor.deleteChar()
                cursor.endEditBlock()

    def get_text(self):
        return self.toPlainText()

    def set_text(self, text):
        self.setPlainText(text)

    def clear_all(self):
        self.clear()


class CustomFileTree(QTreeView):
    def __init__(self, window, parent=None):
        super().__init__(parent)
        self.window = window

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if not urls:
                return
            src = urls[0].toLocalFile()
            index = self.indexAt(event.pos())
            if index.isValid():
                dst_dir = self.window.file_model.filePath(index)
                if not os.path.isdir(dst_dir):
                    dst_dir = os.path.dirname(dst_dir)
            else:
                dst_dir = self.window.root_path or self.window.file_model.rootPath()
            if not src or not dst_dir:
                event.ignore()
                return
            if os.path.isdir(src):
                event.ignore()
                return
            if os.path.dirname(src) == dst_dir:
                event.ignore()
                return
            dst = os.path.join(dst_dir, os.path.basename(src))
            if os.path.exists(dst):
                event.ignore()
                return
            try:
                shutil.move(src, dst)
                self.window._on_file_moved(src, dst)
                event.acceptProposedAction()
                self.window.file_model.setRootPath(self.window.file_model.rootPath())
            except Exception as e:
                QMessageBox.critical(self.window, "Move failed", str(e))
                event.ignore()
        else:
            super().dropEvent(event)


class FileManager:
    def __init__(self):
        self.current_file = None

    def open_path(self, path, parent_widget):
        try:
            encodings = ['utf-8', 'cp1251', 'latin-1', 'cp1252', 'ascii']
            content = None
            for enc in encodings:
                try:
                    with open(path, 'r', encoding=enc) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
                except Exception:
                    continue
            if content is None:
                with open(path, 'rb') as f:
                    raw_data = f.read()
                    content = raw_data.decode('utf-8', errors='replace')
            self.current_file = path
            return content
        except Exception as e:
            QMessageBox.critical(parent_widget, "Error", f"Failed to open file:\n{str(e)}")
            return None

    def save_file(self, path, content, parent_widget):
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
            return True
        except Exception as e:
            QMessageBox.critical(parent_widget, "Error", f"Failed to save file:\n{str(e)}")
            return False


class OutputPanel(QTextBrowser):
    def __init__(self):
        super().__init__()
        self.setReadOnly(True)

    def log(self, text, color="#d4d4d4"):
        safe = (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;"))
        self.append(f'<span style="color:{color};">{safe}</span>')

    def log_raw(self, text):
        if not text:
            return
        safe = (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\n", "<br>"))
        self.append(f'<span style="color:#d4d4d4;">{safe}</span>')

    def clear_output(self):
        self.clear()


class TabData:
    def __init__(self, editor, path=None, language="2dxf"):
        self.editor = editor
        self.path = path
        self.language = language
        self.modified = False
        self.display_name = os.path.basename(path) if path else "Untitled"


class EditorWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.file_manager = FileManager()
        self.output = None
        self.file_model = None
        self.tree = None
        self.root_path = None
        self.tabs = None
        self.tab_data = []
        self.build_process = None
        self._setup_window()
        self._setup_ui()
        self._setup_menu()
        self._setup_statusbar()
        self._apply_theme()

    def _setup_window(self):
        self.setWindowTitle("2DXEngine")
        self.setGeometry(100, 100, 1400, 850)

    def _setup_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setObjectName("MainSplitter")
        splitter.setHandleWidth(1)

        tree_container = QWidget()
        tree_container.setObjectName("TreeContainer")
        tree_layout = QVBoxLayout(tree_container)
        tree_layout.setContentsMargins(0, 0, 0, 0)
        tree_layout.setSpacing(0)

        folder_bar = QWidget()
        folder_bar.setObjectName("FolderBar")
        folder_layout = QHBoxLayout(folder_bar)
        folder_layout.setContentsMargins(8, 4, 8, 4)
        folder_layout.setSpacing(6)

        self.folder_label = QLabel("No project opened")
        self.folder_label.setObjectName("FolderLabel")
        folder_layout.addWidget(self.folder_label, 1)

        tree_layout.addWidget(folder_bar)

        self.tree = CustomFileTree(self)
        self.tree.setObjectName("FileTree")
        self.file_model = QFileSystemModel()
        self.file_model.setRootPath("")
        self.tree.setModel(self.file_model)
        self.tree.setHeaderHidden(True)
        self.tree.setAnimated(True)
        self.tree.setIndentation(16)
        self.tree.setUniformRowHeights(True)
        for col in range(1, 4):
            self.tree.setColumnHidden(col, True)
        self.tree.doubleClicked.connect(self.on_tree_double_click)
        self.tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.tree.customContextMenuRequested.connect(self._tree_context_menu)
        self.tree.setDragEnabled(True)
        self.tree.setAcceptDrops(True)
        self.tree.setDropIndicatorShown(True)
        self.tree.setDragDropMode(QTreeView.DragDrop)
        self.tree.setDefaultDropAction(Qt.MoveAction)
        self.tree.setRootIndex(self.file_model.index(""))
        tree_layout.addWidget(self.tree, 1)

        splitter.addWidget(tree_container)

        right_splitter = QSplitter(Qt.Vertical)
        right_splitter.setObjectName("RightSplitter")
        right_splitter.setHandleWidth(1)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("EditorTabs")
        self.tabs.setTabsClosable(False)
        self.tabs.setMovable(True)
        self.tabs.setDocumentMode(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.currentChanged.connect(self.on_tab_changed)
        right_splitter.addWidget(self.tabs)

        self.output = OutputPanel()
        right_splitter.addWidget(self.output)
        right_splitter.setSizes([600, 150])

        splitter.addWidget(right_splitter)
        splitter.setSizes([280, 1120])

        main_layout.addWidget(splitter, 1)

    def _current_editor(self):
        idx = self.tabs.currentIndex()
        if 0 <= idx < len(self.tab_data):
            return self.tab_data[idx].editor
        return None

    def _current_tab(self):
        idx = self.tabs.currentIndex()
        if 0 <= idx < len(self.tab_data):
            return self.tab_data[idx]
        return None

    def open_new_tab(self, path=None, content=None, language="2dxf"):
        editor = CodeEditor()
        editor.set_language(language)
        if content is not None:
            editor.set_text(content)
        editor.textChanged.connect(self._on_text_changed)
        editor.cursorPositionChanged.connect(self.update_cursor)
        tab = TabData(editor, path=path, language=language)
        idx = self.tabs.addTab(editor, tab.display_name)
        self.tab_data.append(tab)
        self.tabs.setCurrentIndex(idx)
        self._update_tab_tooltip(idx)
        self._install_close_button(idx, editor)
        return tab

    def _install_close_button(self, idx, editor):
        bar = self.tabs.tabBar()
        btn = QToolButton(bar)
        btn.setText("⨯")
        btn.setToolTip("Close tab")
        btn.setAutoRaise(True)
        btn.setStyleSheet("""
            QToolButton {
                border: none;
                background: transparent;
                color: #cccccc;
                font-size: 14px;
                padding: 0px 2px;
            }
            QToolButton:hover {
                background: #c04040;
                color: #ffffff;
                border-radius: 3px;
            }
        """)
        btn.clicked.connect(lambda checked=False, ed=editor: self._close_tab_by_editor(ed))
        bar.setTabButton(idx, QTabBar.RightSide, btn)

    def _close_tab_by_editor(self, editor):
        for i, tab in enumerate(self.tab_data):
            if tab.editor is editor:
                self.close_tab(i)
                return

    def _update_tab_tooltip(self, idx):
        if 0 <= idx < len(self.tab_data):
            tab = self.tab_data[idx]
            self.tabs.setTabToolTip(idx, tab.path if tab.path else "Unsaved")

    def _on_text_changed(self):
        editor = self.sender()
        for i, tab in enumerate(self.tab_data):
            if tab.editor == editor:
                if not tab.modified:
                    tab.modified = True
                    self.tabs.setTabText(i, tab.display_name + " *")
                break

    def close_tab(self, idx):
        if idx < 0 or idx >= len(self.tab_data):
            return
        tab = self.tab_data[idx]
        if tab.modified:
            reply = QMessageBox.question(
                self, "Unsaved changes",
                f"Save changes to '{tab.display_name}'?",
                QMessageBox.Save | QMessageBox.Discard | QMessageBox.Cancel
            )
            if reply == QMessageBox.Cancel:
                return
            if reply == QMessageBox.Save:
                self.tabs.setCurrentIndex(idx)
                if not self.save_current_file():
                    return
        self.tabs.removeTab(idx)
        self.tab_data.pop(idx)

    def close_current_tab(self):
        self.close_tab(self.tabs.currentIndex())

    def on_tab_changed(self, idx):
        if 0 <= idx < len(self.tab_data):
            tab = self.tab_data[idx]
            name = tab.display_name + (" *" if tab.modified else "")
            self.file_label.setText(name)
            self.setWindowTitle(f"2DXEngine - {name}")
        else:
            self.file_label.setText("No file opened")
            self.setWindowTitle("2DXEngine")
        self.update_cursor()

    def _setup_menu(self):
        menubar = self.menuBar()
        menubar.setObjectName("MenuBar")

        file_menu = menubar.addMenu("File")
        file_menu.addAction(self._create_action("New Project...", None, self.create_project))
        file_menu.addAction(self._create_action("Open Project...", None, self.open_project))
        file_menu.addSeparator()
        file_menu.addAction(self._create_action("Save File", None, self.save_current_file))
        file_menu.addAction(self._create_action("Save Project", None, self.save_project))
        file_menu.addSeparator()
        file_menu.addAction(self._create_action("Close Tab", None, self.close_current_tab))
        file_menu.addAction(self._create_action("Exit", "Alt+F4", self.close))

        project_menu = menubar.addMenu("Project")
        project_menu.addAction(self._create_action("Project Settings...", None, self.open_project_settings))
        project_menu.addSeparator()
        project_menu.addAction(self._create_action("Build", "F7", self.build_project))
        project_menu.addAction(self._create_action("Build and Run", "F5", self.build_and_run))
        project_menu.addAction(self._create_action("Run", "Ctrl+F5", self.run_last_build))

        edit_menu = menubar.addMenu("Edit")
        edit_menu.addAction(self._create_action("Undo", None, self.undo))
        edit_menu.addAction(self._create_action("Redo", None, self.redo))
        edit_menu.addSeparator()
        edit_menu.addAction(self._create_action("Cut", None, self.cut))
        edit_menu.addAction(self._create_action("Copy", None, self.copy))
        edit_menu.addAction(self._create_action("Paste", None, self.paste))
        edit_menu.addAction(self._create_action("Select All", None, self.select_all))

        view_menu = menubar.addMenu("View")
        view_menu.addAction(self._create_action("Clear Output", None, self.clear_output))

    def _setup_statusbar(self):
        self.status_bar = self.statusBar()
        self.file_label = QLabel("No file opened")
        self.file_label.setObjectName("StatusLabel")
        self.status_bar.addWidget(self.file_label)
        self.cursor_label = QLabel("Line: 1 | Col: 1")
        self.cursor_label.setObjectName("StatusLabel")
        self.status_bar.addPermanentWidget(self.cursor_label)

    def _create_action(self, name, shortcut, callback):
        action = QAction(name, self)
        if shortcut:
            action.setShortcut(shortcut)
        action.triggered.connect(lambda checked=False, cb=callback: self._safe(cb)())
        return action

    def _safe(self, func):
        def wrapper(*args, **kwargs):
            try:
                func()
            except Exception as e:
                if self.output:
                    self.output.log(f"Error: {e}", "#E06C75")
                QMessageBox.warning(self, "Error", str(e))
        return wrapper

    def update_cursor(self):
        editor = self._current_editor()
        if editor:
            cursor = editor.textCursor()
            line = cursor.blockNumber() + 1
            col = cursor.columnNumber() + 1
            self.cursor_label.setText(f"Line: {line} | Col: {col}")
        else:
            self.cursor_label.setText("Line: - | Col: -")

    def create_project(self):
        start = os.path.expanduser("~")
        folder = QFileDialog.getExistingDirectory(
            self, "Select folder for new project", start
        )
        if not folder:
            return
        project_file = os.path.join(folder, "project.2dxp")
        assets_dir = os.path.join(folder, "assets")
        if os.path.isfile(project_file):
            reply = QMessageBox.question(
                self, "Project exists",
                f"'{folder}' already contains project.2dxp.\nOpen it instead?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                save_last_project(folder)
                self._launch_new_editor(folder)
            return
        try:
            os.makedirs(assets_dir, exist_ok=True)
            with open(project_file, "w", encoding="utf-8") as f:
                json.dump({}, f)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create project:\n{e}")
            return

        core_src = get_core_source_dir()
        if core_src:
            core_dst = os.path.join(folder, "core")
            if os.path.exists(core_dst):
                reply = QMessageBox.question(
                    self, "Core exists",
                    f"Core folder already exists in:\n{folder}\nOverwrite?",
                    QMessageBox.Yes | QMessageBox.No
                )
                if reply == QMessageBox.Yes:
                    try:
                        shutil.rmtree(core_dst)
                    except Exception as e:
                        QMessageBox.critical(self, "Error", f"Failed to remove existing core:\n{e}")
                        return
            if not os.path.exists(core_dst):
                try:
                    shutil.copytree(core_src, core_dst)
                    self.output.log(f"Core copied to: {core_dst}", "#98C379")
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Failed to copy core folder:\n{e}")
        else:
            QMessageBox.warning(self, "Core not found",
                                "Could not find 'core' folder next to the executable.\n"
                                "Project created without core.")

        save_last_project(folder)
        self.output.log(f"Project created: {folder}", "#98C379")
        self._launch_new_editor(folder)

    def _launch_new_editor(self, folder):
        new_window = EditorWindow()
        new_window.open_project_path(folder)
        new_window.show()
        self.output.log(f"Opened in new window: {folder}", "#E5C07B")

    def open_project(self):
        start = self.root_path or os.path.expanduser("~")
        path, _ = QFileDialog.getOpenFileName(
            self, "Open Project", start,
            "2DX Engine Project (project.2dxp);;All Files (*.*)"
        )
        if not path:
            return
        if os.path.basename(path) != "project.2dxp":
            QMessageBox.warning(
                self, "Invalid Project File",
                "Please select a 'project.2dxp' file."
            )
            return
        folder = os.path.dirname(path)
        self.open_project_path(folder)

    def open_project_path(self, folder):
        if not os.path.isfile(os.path.join(folder, "project.2dxp")):
            QMessageBox.warning(self, "Error", f"project.2dxp not found in:\n{folder}")
            return
        self.root_path = folder
        save_last_project(folder)
        self.folder_label.setText(os.path.basename(folder) or folder)
        self.folder_label.setToolTip(folder)
        assets_path = os.path.join(folder, "assets")
        if os.path.isdir(assets_path):
            self._show_only(assets_path)
        else:
            self._show_only(folder)
        self.output.log(f"Project opened: {folder}", "#E5C07B")
        self.setWindowTitle(f"2DXEngine - {os.path.basename(folder) or folder}")

    def _show_only(self, path):
        idx = self.file_model.setRootPath(path)
        self.tree.setRootIndex(idx)

    def _open_tree_path(self, path):
        if os.path.isfile(path):
            content = self.file_manager.open_path(path, self)
            if content is not None:
                for i, tab in enumerate(self.tab_data):
                    if tab.path == path:
                        self.tabs.setCurrentIndex(i)
                        return
                language = self._language_for_path(path)
                self.open_new_tab(path=path, content=content, language=language)
                self.output.log(f"Opened: {path}", "#98C379")

    def on_tree_double_click(self, index):
        if not index.isValid():
            return
        path = self.file_model.filePath(index)
        self._open_tree_path(path)

    def _language_for_path(self, path):
        ext = os.path.splitext(path)[1].lower()
        mapping = {
            ".cpp": "cpp", ".c": "cpp", ".h": "cpp", ".hpp": "cpp",
            ".cc": "cpp", ".cxx": "cpp", ".hxx": "cpp",
            ".py": "python", ".json": "json", ".js": "js",
            ".html": "html", ".htm": "html", ".xml": "html",
            ".css": "css", ".md": "md", ".markdown": "md",
            ".2dxf": "2dxf",
        }
        return mapping.get(ext, "generic")

    def _tree_context_menu(self, pos):
        index = self.tree.indexAt(pos)
        menu = QMenu(self.tree)
        menu.setStyleSheet(self._menu_qss())

        if index.isValid():
            path = self.file_model.filePath(index)
            if os.path.isdir(path):
                new_file = menu.addAction("New File...")
                new_file.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._create_new_file(p))()
                )
                new_dir = menu.addAction("New Folder...")
                new_dir.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._create_new_folder(p))()
                )
                menu.addSeparator()
                rename_action = menu.addAction("Rename...")
                rename_action.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._rename_path(p))()
                )
                delete_action = menu.addAction("Delete")
                delete_action.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._delete_path(p))()
                )
            elif os.path.isfile(path):
                open_action = menu.addAction("Open")
                open_action.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._open_tree_path(p))()
                )
                menu.addSeparator()
                rename_action = menu.addAction("Rename...")
                rename_action.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._rename_path(p))()
                )
                delete_action = menu.addAction("Delete")
                delete_action.triggered.connect(
                    lambda checked=False, p=path: self._safe(lambda: self._delete_path(p))()
                )
        else:
            target = self._context_target_dir()
            if target:
                new_file = menu.addAction("New File...")
                new_file.triggered.connect(
                    lambda checked=False, p=target: self._safe(lambda: self._create_new_file(p))()
                )
                new_dir = menu.addAction("New Folder...")
                new_dir.triggered.connect(
                    lambda checked=False, p=target: self._safe(lambda: self._create_new_folder(p))()
                )

        if menu.actions():
            menu.exec_(self.tree.viewport().mapToGlobal(pos))

    def _context_target_dir(self):
        if self.root_path and os.path.isdir(self.root_path):
            assets = os.path.join(self.root_path, "assets")
            if os.path.isdir(assets):
                return assets
            return self.root_path
        root = self.file_model.rootPath()
        if root and os.path.isdir(root):
            return root
        return None

    def _menu_qss(self):
        return """
            QMenu { background-color: #252526; color: #cccccc; border: 1px solid #3e3e42; padding: 4px; }
            QMenu::item { padding: 5px 24px 5px 24px; border-radius: 3px; }
            QMenu::item:selected { background-color: #04395e; }
            QMenu::separator { height: 1px; background: #3e3e42; margin: 4px 8px; }
        """

    def _create_new_file(self, directory):
        if not os.path.isdir(directory):
            QMessageBox.warning(self, "Error", "Target is not a directory.")
            return
        name, ok = QInputDialog.getText(
            self, "New File",
            "Enter file name (with extension, e.g. main.cpp, data.json, notes.txt):",
            QLineEdit.Normal, ""
        )
        if not ok:
            return
        name = name.strip()
        if not name:
            return
        if os.sep in name or (os.altsep and os.altsep in name):
            QMessageBox.warning(self, "Error", "File name must not contain path separators.")
            return
        full_path = os.path.join(directory, name)
        if os.path.exists(full_path):
            QMessageBox.warning(self, "Error", f"File already exists:\n{full_path}")
            return
        try:
            with open(full_path, 'w', encoding='utf-8') as f:
                f.write('')
            self.output.log(f"Created: {full_path}", "#98C379")
            self.file_model.setRootPath(self.file_model.rootPath())
            self._open_tree_path(full_path)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create file:\n{str(e)}")

    def _create_new_folder(self, directory):
        if not os.path.isdir(directory):
            QMessageBox.warning(self, "Error", "Target is not a directory.")
            return
        name, ok = QInputDialog.getText(
            self, "New Folder",
            "Enter folder name:",
            QLineEdit.Normal, ""
        )
        if not ok:
            return
        name = name.strip()
        if not name:
            return
        if os.sep in name or (os.altsep and os.altsep in name):
            QMessageBox.warning(self, "Error", "Name must not contain path separators.")
            return
        full_path = os.path.join(directory, name)
        if os.path.exists(full_path):
            QMessageBox.warning(self, "Error", f"Already exists:\n{full_path}")
            return
        try:
            os.makedirs(full_path)
            self.output.log(f"Created folder: {full_path}", "#98C379")
            self.file_model.setRootPath(self.file_model.rootPath())
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to create folder:\n{str(e)}")

    def _rename_path(self, path):
        if not os.path.exists(path):
            return
        old_name = os.path.basename(path)
        new_name, ok = QInputDialog.getText(
            self, "Rename",
            "Enter new name (with extension):",
            QLineEdit.Normal, old_name
        )
        if not ok:
            return
        new_name = new_name.strip()
        if not new_name or new_name == old_name:
            return
        if os.sep in new_name or (os.altsep and os.altsep in new_name):
            QMessageBox.warning(self, "Error", "Name must not contain path separators.")
            return
        directory = os.path.dirname(path)
        new_path = os.path.join(directory, new_name)
        if os.path.exists(new_path):
            QMessageBox.warning(self, "Error", f"Already exists:\n{new_path}")
            return
        try:
            os.rename(path, new_path)
            for tab in self.tab_data:
                if tab.path == path:
                    tab.path = new_path
                    tab.display_name = new_name
                    tab.language = self._language_for_path(new_path)
                    tab.editor.set_language(tab.language)
                    break
            self._refresh_tabs()
            self.file_model.setRootPath(self.file_model.rootPath())
            self.output.log(f"Renamed: {path} -> {new_path}", "#98C379")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Rename failed:\n{str(e)}")

    def _delete_path(self, path):
        if not os.path.exists(path):
            return
        reply = QMessageBox.question(
            self, "Delete",
            f"Delete '{os.path.basename(path)}'?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return
        try:
            if os.path.isdir(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
            for i, tab in enumerate(list(self.tab_data)):
                if tab.path == path or (os.path.isdir(path) and tab.path and tab.path.startswith(path + os.sep)):
                    self.tabs.removeTab(i)
                    self.tab_data.pop(i)
            self.file_model.setRootPath(self.file_model.rootPath())
            self.output.log(f"Deleted: {path}", "#E06C75")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Delete failed:\n{str(e)}")

    def _on_file_moved(self, src, dst):
        for tab in self.tab_data:
            if tab.path == src:
                tab.path = dst
                tab.display_name = os.path.basename(dst)
                tab.language = self._language_for_path(dst)
                tab.editor.set_language(tab.language)
        self._refresh_tabs()
        self.output.log(f"Moved: {src} -> {dst}", "#98C379")

    def _refresh_tabs(self):
        for i, tab in enumerate(self.tab_data):
            name = tab.display_name + (" *" if tab.modified else "")
            self.tabs.setTabText(i, name)
            self.tabs.setTabToolTip(i, tab.path if tab.path else "Unsaved")

    def save_current_file(self):
        tab = self._current_tab()
        if not tab:
            return False
        if not tab.path:
            QMessageBox.warning(self, "Error", "This tab has no file path. Create a file in the tree first.")
            return False
        if self.file_manager.save_file(tab.path, tab.editor.get_text(), self):
            tab.modified = False
            idx = self.tabs.currentIndex()
            self.tabs.setTabText(idx, tab.display_name)
            self.output.log(f"Saved: {tab.path}", "#98C379")
            return True
        return False

    def save_project(self):
        if not self.root_path:
            QMessageBox.warning(self, "Error", "No project is open.")
            return
        project_file = os.path.join(self.root_path, "project.2dxp")
        if not os.path.isfile(project_file):
            QMessageBox.warning(self, "Error", "project.2dxp not found in project root.")
            return
        for tab in self.tab_data:
            if not tab.path:
                continue
            try:
                if os.path.abspath(tab.path).startswith(os.path.abspath(self.root_path) + os.sep) \
                        or os.path.abspath(tab.path) == os.path.abspath(project_file):
                    if self.file_manager.save_file(tab.path, tab.editor.get_text(), self):
                        tab.modified = False
                        idx = self.tab_data.index(tab)
                        self.tabs.setTabText(idx, tab.display_name)
            except Exception:
                pass
        saved = 0
        failed = []
        for dirpath, dirnames, filenames in os.walk(self.root_path):
            for fname in filenames:
                fpath = os.path.join(dirpath, fname)
                try:
                    with open(fpath, 'rb') as f:
                        data = f.read()
                    with open(fpath, 'wb') as f:
                        f.write(data)
                    saved += 1
                except Exception as e:
                    failed.append(f"{fpath}: {e}")
        if failed:
            self.output.log(f"Save Project: {saved} files saved, {len(failed)} failed", "#E06C75")
            for f in failed:
                self.output.log(f"  Failed: {f}", "#E06C75")
        else:
            self.output.log(f"Save Project: {saved} files saved (entire project root)", "#98C379")

    def open_project_settings(self):
        if not self.root_path:
            QMessageBox.warning(self, "Error", "No project is open.")
            return
        settings_path = os.path.join(self.root_path, "core", "main", "settings.h")
        if not os.path.isfile(settings_path):
            QMessageBox.warning(self, "Error", f"settings.h not found:\n{settings_path}")
            return
        build_data = read_project_json(self.root_path).get("build", {})
        dlg = SettingsDialog(self, settings_path, build_data)
        dlg.setStyleSheet(self._menu_qss())
        if dlg.exec_() == QDialog.Accepted:
            self.output.log(f"Settings saved: {settings_path}", "#98C379")
            data = read_project_json(self.root_path)
            data["build"] = dlg.get_build_settings()
            try:
                write_project_json(self.root_path, data)
                self.output.log(f"Build settings saved: project.2dxp", "#98C379")
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Failed to save project.2dxp:\n{e}")

    def _get_build_settings(self):
        if not self.root_path:
            return {}
        b = read_project_json(self.root_path).get("build", {})
        defaults = {
            "save_before_build": True,
            "vcpkg_path": "C:\\vcpkg\\installed\\x64-windows",
            "clang_path": "clang-cl.exe",
            "cpp_std": "c++17",
            "output_name": "new_project.exe",
            "subsystem": "WINDOWS",
            "extra_libs": "user32.lib gdi32.lib",
            "extra_includes": "",
            "launch_after_build": True,
            "log_output": True,
        }
        result = dict(defaults)
        result.update(b)
        return result

    def _generate_build_bat(self, settings):
        bat_path = get_build_bat_path()
        if not bat_path:
            QMessageBox.warning(self, "Error",
                                "build/build.bat not found next to editor executable.")
            return None
        if not self.root_path:
            QMessageBox.warning(self, "Error", "No project is open.")
            return None

        vcpkg = settings.get("vcpkg_path", "C:\\vcpkg\\installed\\x64-windows")
        clang = settings.get("clang_path", "clang-cl.exe")
        cpp_std = settings.get("cpp_std", "c++17")
        output_name = settings.get("output_name", "Caretaker.exe")
        subsystem = settings.get("subsystem", "WINDOWS")
        extra_libs = settings.get("extra_libs", "user32.lib gdi32.lib")
        extra_includes = settings.get("extra_includes", "")

        proj = self.root_path.replace("\\", "\\\\")

        inc_lines = f' "/I{proj}" ^\n "/I{proj}\\core\\libs\\glad\\include"'
        if extra_includes.strip():
            for inc in extra_includes.split(";"):
                inc = inc.strip()
                if inc:
                    inc = inc.replace("\\", "\\\\")
                    inc_lines += f' ^\n "/I{inc}"'
        libs_lines = extra_libs.strip() if extra_libs.strip() else ""

        bat_content = f'''@echo off
setlocal enabledelayedexpansion

set "PROJECT_ROOT={proj}"
set "FILES=%PROJECT_ROOT%\\files"

if not exist "%FILES%" md "%FILES%"
if not exist "%FILES%\\assets" md "%FILES%\\assets"
if not exist "%FILES%\\core" md "%FILES%\\core"

xcopy /E /I /H /Y "%PROJECT_ROOT%\\assets" "%FILES%\\assets" >nul
rd /s /q "%FILES%\\assets\\scripts" 2>nul

xcopy /E /I /H /Y "%PROJECT_ROOT%\\core" "%FILES%\\core" >nul
rd /s /q "%FILES%\\core\\libs" 2>nul
rd /s /q "%FILES%\\core\\main" 2>nul
rd /s /q "%FILES%\\core\\other" 2>nul
rd /s /q "%FILES%\\core\\plugins" 2>nul
rd /s /q "%FILES%\\core\\ui" 2>nul

set "LIST=%TEMP%\\2dx_src_%RANDOM%.txt"
if exist "%LIST%" del "%LIST%"

for /f "usebackq delims=" %%F in (`dir /s /b "%PROJECT_ROOT%\\*.cpp" "%PROJECT_ROOT%\\*.c" 2^>nul`) do (
    echo "%%F">>"%LIST%"
)

if not exist "%LIST%" (
    echo No source files found.
    exit /b 1
)

set VCPKG={vcpkg}

set INC=/I%VCPKG%\\include ^
{inc_lines}

{clang} /EHsc /std:{cpp_std} %INC% @"%LIST%" ^
 /Fe:"%FILES%/{output_name}" ^
 /link /SUBSYSTEM:{subsystem} /ENTRY:mainCRTStartup ^
 /LIBPATH:%VCPKG%\\lib ^
 glfw3dll.lib opengl32.lib ^
 freetype.lib bz2.lib zlib.lib brotlidec.lib brotlicommon.lib libpng16.lib ^
 {libs_lines}

set "ERR=%ERRORLEVEL%"
del "%LIST%" 2>nul

if %ERR% neq 0 (
    echo Build failed.
    exit /b %ERR%
) else (
    copy /Y %VCPKG%\\bin\\glfw3.dll "%FILES%\\" >nul
    echo Build succeeded.
    exit /b 0
)
'''
        try:
            with open(bat_path, "w", encoding="utf-8") as f:
                f.write(bat_content)
            self.output.log(f"Updated build.bat: {bat_path}", "#98C379")
            return bat_path
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to write build.bat:\n{e}")
            return None

    def build_project(self):
        if not self.root_path:
            QMessageBox.warning(self, "Error", "No project is open.")
            return
        settings = self._get_build_settings()
        if settings.get("save_before_build", True):
            self.save_project()
        bat_path = self._generate_build_bat(settings)
        if not bat_path:
            return
        build_dir = os.path.dirname(bat_path)
        self.output.clear_output()
        self.output.log(f"=== Build started: {self.root_path} ===", "#61AFEF")
        if self.build_process is not None:
            try:
                self.build_process.kill()
            except Exception:
                pass
            self.build_process = None
        self.build_process = QProcess(self)
        self.build_process.setWorkingDirectory(build_dir)
        self.build_process.setProcessChannelMode(QProcess.MergedChannels)
        self.build_process.readyReadStandardOutput.connect(self._on_build_output)
        self.build_process.finished.connect(
            lambda code, status: self._on_build_finished(code, status)
        )
        self.build_process.start("cmd.exe", ["/c", bat_path])
        if not self.build_process.waitForStarted(3000):
            QMessageBox.critical(self, "Error", "Failed to start build process.")

    def _on_build_output(self):
        if not self.build_process:
            return
        data = self.build_process.readAllStandardOutput()
        if data:
            raw = bytes(data)
            try:
                text = raw.decode("cp866")
            except Exception:
                text = raw.decode("utf-8", errors="replace")
            self.output.log_raw(text)

    def _on_build_finished(self, code, status):
        if code == 0:
            self.output.log("=== Build succeeded ===", "#98C379")
        else:
            self.output.log(f"=== Build failed (exit code {code}) ===", "#E06C75")

    def _get_exe_path(self):
        if not self.root_path:
            return None
        settings = self._get_build_settings()
        output_name = settings.get("output_name", "Caretaker.exe")
        exe_path = os.path.join(self.root_path, "files", output_name)
        return exe_path if os.path.isfile(exe_path) else None

    def _launch_built_app(self):
        exe_path = self._get_exe_path()
        if not exe_path:
            QMessageBox.warning(self, "Error",
                                "Built executable not found. Build the project first.")
            return
        files_dir = os.path.dirname(exe_path)
        self.output.log(f"=== Launching: {exe_path} ===", "#61AFEF")
        try:
            subprocess.Popen([exe_path], cwd=files_dir, shell=False)
        except Exception as e:
            self.output.log(f"Failed to launch: {e}", "#E06C75")

    def build_and_run(self):
        if not self.root_path:
            QMessageBox.warning(self, "Error", "No project is open.")
            return
        settings = self._get_build_settings()
        if settings.get("save_before_build", True):
            self.save_project()
        bat_path = self._generate_build_bat(settings)
        if not bat_path:
            return
        build_dir = os.path.dirname(bat_path)
        self.output.clear_output()
        self.output.log(f"=== Build started: {self.root_path} ===", "#61AFEF")
        if self.build_process is not None:
            try:
                self.build_process.kill()
            except Exception:
                pass
            self.build_process = None
        self.build_process = QProcess(self)
        self.build_process.setWorkingDirectory(build_dir)
        self.build_process.setProcessChannelMode(QProcess.MergedChannels)
        self.build_process.readyReadStandardOutput.connect(self._on_build_output)
        self.build_process.finished.connect(
            lambda code, status: self._on_build_and_run_finished(code, status)
        )
        self.build_process.start("cmd.exe", ["/c", bat_path])
        if not self.build_process.waitForStarted(3000):
            QMessageBox.critical(self, "Error", "Failed to start build process.")

    def _on_build_and_run_finished(self, code, status):
        if code == 0:
            self.output.log("=== Build succeeded ===", "#98C379")
            self._launch_built_app()
        else:
            self.output.log(f"=== Build failed (exit code {code}) ===", "#E06C75")

    def run_last_build(self):
        if not self.root_path:
            QMessageBox.warning(self, "Error", "No project is open.")
            return
        self._launch_built_app()

    def undo(self):
        editor = self._current_editor()
        if editor:
            editor.undo()

    def redo(self):
        editor = self._current_editor()
        if editor:
            editor.redo()

    def cut(self):
        editor = self._current_editor()
        if editor:
            editor.cut()

    def copy(self):
        editor = self._current_editor()
        if editor:
            editor.copy()

    def paste(self):
        editor = self._current_editor()
        if editor:
            editor.paste()

    def select_all(self):
        editor = self._current_editor()
        if editor:
            editor.selectAll()

    def clear_output(self):
        self.output.clear_output()

    def _apply_theme(self):
        self.setStyleSheet("""
            QMainWindow, QWidget {
                background-color: #1e1e1e;
                color: #cccccc;
                font-family: 'Segoe UI', sans-serif;
                font-size: 12px;
            }
            QMenuBar {
                background-color: #252526;
                color: #cccccc;
                border-bottom: 1px solid #3e3e42;
                padding: 2px;
            }
            QMenuBar::item { background: transparent; padding: 4px 10px; border-radius: 3px; }
            QMenuBar::item:selected { background-color: #04395e; }
            QMenu {
                background-color: #252526;
                color: #cccccc;
                border: 1px solid #3e3e42;
                padding: 4px;
            }
            QMenu::item { padding: 5px 24px 5px 24px; border-radius: 3px; }
            QMenu::item:selected { background-color: #04395e; }
            QMenu::separator { height: 1px; background: #3e3e42; margin: 4px 8px; }
            QWidget#TreeContainer { background-color: #1e1e1e; }
            QWidget#FolderBar { background-color: #252526; border-bottom: 1px solid #3e3e42; }
            QLabel#FolderLabel { color: #dddddd; font-weight: bold; font-size: 11px; }
            QTreeView#FileTree {
                background-color: #1e1e1e;
                color: #d0d0d0;
                border: none;
                font-size: 12px;
                outline: 0;
                padding: 4px 2px;
                show-decoration-selected: 1;
            }
            QTreeView#FileTree::item {
                padding: 4px 6px;
                border-radius: 4px;
                margin: 1px 4px;
            }
            QTreeView#FileTree::item:hover { background-color: #2a2d2e; }
            QTreeView#FileTree::item:selected { background-color: #04395e; color: #ffffff; }
            QTreeView#FileTree::branch { background: transparent; }
            QTabWidget#EditorTabs::pane {
                border: none;
                background-color: #1e1e1e;
            }
            QTabWidget#EditorTabs QTabBar::tab {
                background-color: #252526;
                color: #cccccc;
                border: 1px solid #3e3e42;
                border-bottom: none;
                padding: 6px 12px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                min-width: 100px;
            }
            QTabWidget#EditorTabs QTabBar::tab:selected {
                background-color: #1e1e1e;
                color: #ffffff;
                border-color: #3e3e42;
            }
            QTabWidget#EditorTabs QTabBar::tab:hover:!selected {
                background-color: #2a2d2e;
            }
            QTabWidget#EditorTabs QTabBar {
                background-color: #252526;
            }
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: none;
                selection-background-color: #264f78;
                selection-color: #ffffff;
            }
            QTextBrowser {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: none;
                border-top: 1px solid #3e3e42;
                padding: 6px;
            }
            QStatusBar {
                background-color: #252526;
                color: #cccccc;
                border-top: 1px solid #3e3e42;
            }
            QLabel#StatusLabel { color: #cccccc; padding: 0 10px; }
            QSplitter::handle { background-color: #3e3e42; }
            QSplitter::handle:hover { background-color: #04395e; }
            QScrollBar:vertical { background: #1e1e1e; width: 12px; border: none; }
            QScrollBar::handle:vertical {
                background: #424246;
                min-height: 20px;
                border-radius: 6px;
                margin: 2px;
            }
            QScrollBar::handle:vertical:hover { background: #525256; }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
            QScrollBar:horizontal { background: #1e1e1e; height: 12px; border: none; }
            QScrollBar::handle:horizontal {
                background: #424246;
                min-width: 20px;
                border-radius: 6px;
                margin: 2px;
            }
            QScrollBar::handle:horizontal:hover { background: #525256; }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
            QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background: none; }
            QLineEdit, QSpinBox, QComboBox {
                background-color: #2d2d30;
                color: #d4d4d4;
                border: 1px solid #3e3e42;
                border-radius: 3px;
                padding: 4px;
            }
            QCheckBox { color: #cccccc; }
            QTabWidget::pane { border: 1px solid #3e3e42; }
            QTabWidget QTabBar::tab {
                background-color: #2d2d30;
                color: #cccccc;
                padding: 6px 14px;
                border: 1px solid #3e3e42;
                border-bottom: none;
            }
            QTabWidget QTabBar::tab:selected { background-color: #1e1e1e; color: #ffffff; }
            QDialogButtonBox QPushButton {
                background-color: #2d2d30;
                color: #d4d4d4;
                border: 1px solid #3e3e42;
                border-radius: 3px;
                padding: 5px 16px;
            }
            QDialogButtonBox QPushButton:hover { background-color: #04395e; }
        """)


def main():
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    app = QApplication(sys.argv)
    app.setApplicationName("2DXEngine")
    app.setStyle(QStyleFactory.create("Fusion"))
    window = EditorWindow()
    last = load_last_project()
    if last:
        window.open_project_path(last)
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()